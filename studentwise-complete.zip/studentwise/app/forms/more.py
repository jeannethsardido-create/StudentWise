from datetime import date
from decimal import Decimal
from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileRequired, FileAllowed
from wtforms import (BooleanField, StringField, DecimalField, SelectField, DateField, TextAreaField, PasswordField,
                     SubmitField)
from wtforms.validators import DataRequired, Length, NumberRange, Optional, EqualTo

POSITIVE = [DataRequired(), NumberRange(min=Decimal("0.01"), message="Must be greater than zero.")]


class BillForm(FlaskForm):
    name = StringField("Bill name", validators=[DataRequired(), Length(max=100)])
    amount = DecimalField("Amount (\u20b1)", places=2, validators=POSITIVE)
    due_date = DateField("Due date", default=date.today, validators=[DataRequired()])
    category_id = SelectField("Category", coerce=int)
    account_id = SelectField("Pay from account", coerce=int)
    notes = TextAreaField("Notes", validators=[Optional(), Length(max=1000)])
    submit = SubmitField("Save")


class RecurringForm(FlaskForm):
    name = StringField("Name", validators=[DataRequired(), Length(max=100)])
    amount = DecimalField("Amount (\u20b1)", places=2, validators=POSITIVE)
    frequency = SelectField("Repeats", choices=[("monthly", "Monthly"), ("weekly", "Weekly")])
    start_date = DateField("First due date", default=date.today, validators=[DataRequired()])
    end_date = DateField("Ends on (optional)", validators=[Optional()])
    category_id = SelectField("Category", coerce=int)
    account_id = SelectField("Pay from account", coerce=int)
    submit = SubmitField("Save")


class GoalForm(FlaskForm):
    name = StringField("Goal name", validators=[DataRequired(), Length(max=100)])
    target_amount = DecimalField("Target amount (\u20b1)", places=2, validators=POSITIVE)
    target_date = DateField("Target date (optional)", validators=[Optional()])
    submit = SubmitField("Save")


class EntryForm(FlaskForm):
    entry_type = SelectField("Action", choices=[("contribution", "Add to savings"), ("withdrawal", "Withdraw")])
    amount = DecimalField("Amount (\u20b1)", places=2, validators=POSITIVE)
    entry_date = DateField("Date", default=date.today, validators=[DataRequired()])
    notes = StringField("Notes", validators=[Optional(), Length(max=255)])
    submit = SubmitField("Save")


class UploadForm(FlaskForm):
    account_id = SelectField("Import into account", coerce=int)
    file = FileField("CSV statement", validators=[FileRequired(), FileAllowed(["csv"], "Upload a .csv file.")])
    submit = SubmitField("Upload and preview")


class ProfileForm(FlaskForm):
    name = StringField("Full name", validators=[DataRequired(), Length(max=100)])
    submit = SubmitField("Save name")


class PasswordForm(FlaskForm):
    current = PasswordField("Current password", validators=[DataRequired()])
    new = PasswordField("New password", validators=[DataRequired(), Length(min=8)])
    confirm = PasswordField("Confirm new password", validators=[DataRequired(), EqualTo("new", message="Passwords must match.")])
    submit = SubmitField("Change password")


class AccountForm(FlaskForm):
    account_name = StringField("Account name", validators=[DataRequired(), Length(max=100)])
    account_type = SelectField("Type", choices=[("cash", "Cash"), ("ewallet", "E-wallet (manual)"), ("bank", "Bank (manual)")])
    provider = StringField("Provider (e.g. GCash, Maya)", validators=[Optional(), Length(max=50)])
    submit = SubmitField("Add account")


class DeleteForm(FlaskForm):
    password = PasswordField("Your password", validators=[DataRequired()])
    submit = SubmitField("Delete my account")


class NotifyForm(FlaskForm):
    phone = StringField("Mobile number (optional, Philippines)", validators=[Optional(), Length(max=20)])
    notify_email = BooleanField("Email me alerts")
    notify_sms = BooleanField("Text me alerts (needs SMS service)")
    submit = SubmitField("Save alert settings")
