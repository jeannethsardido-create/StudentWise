from datetime import date
from decimal import Decimal
from flask_wtf import FlaskForm
from wtforms import (StringField, DecimalField, SelectField, DateField, TextAreaField,
                     IntegerField, SubmitField)
from wtforms.validators import DataRequired, Length, NumberRange, Optional


class TransactionForm(FlaskForm):
    transaction_type = SelectField("Type", choices=[("expense", "Expense"), ("income", "Income")])
    description = StringField("Description", validators=[DataRequired(), Length(max=255)])
    amount = DecimalField("Amount (\u20b1)", places=2,
                          validators=[DataRequired(), NumberRange(min=Decimal("0.01"), message="Must be greater than zero.")])
    account_id = SelectField("Account", coerce=int)
    category_id = SelectField("Category", coerce=int)
    transaction_date = DateField("Date", default=date.today, validators=[DataRequired()])
    status = SelectField("Status", choices=[("completed", "Completed"), ("pending", "Pending"),
                                            ("failed", "Failed"), ("reversed", "Reversed")])
    notes = TextAreaField("Notes", validators=[Optional(), Length(max=1000)])
    submit = SubmitField("Save")


class BudgetForm(FlaskForm):
    name = StringField("Budget name", validators=[DataRequired(), Length(max=100)])
    budget_amount = DecimalField("Budget limit (\u20b1)", places=2,
                                 validators=[NumberRange(min=Decimal("0"), message="Cannot be negative.")])
    period_type = SelectField("Type", choices=[("daily", "Daily"), ("weekly", "Weekly"), ("monthly", "Monthly"),
                                               ("category", "Category"), ("custom", "Custom period")])
    category_id = SelectField("Category (optional)", coerce=int)
    start_date = DateField("Start date", validators=[DataRequired()])
    end_date = DateField("End date", validators=[DataRequired()])
    warning_threshold = IntegerField("Warn at % used", default=75,
                                     validators=[NumberRange(min=1, max=100)])
    submit = SubmitField("Save")
