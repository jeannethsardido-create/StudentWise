from flask import Blueprint, render_template, redirect, url_for, flash, abort, send_from_directory, current_app
from flask_login import login_required, current_user
from app.forms.more import UploadForm
from app.models import ImportBatch
from app.services.import_service import ImportService, ImportError_
from app.utils.choices import account_choices
from flask_wtf import FlaskForm

imports_bp = Blueprint("imports", __name__, url_prefix="/import")


@imports_bp.route("/", methods=["GET", "POST"])
@login_required
def index():
    form = UploadForm()
    form.account_id.choices = account_choices(current_user.id)
    if form.validate_on_submit():
        f = form.file.data
        try:
            batch = ImportService.start_preview(current_user, form.account_id.data, f.filename, f.read())
            return redirect(url_for("imports.preview", batch_id=batch.id))
        except ImportError_ as e:
            flash(str(e), "danger")
    history = ImportBatch.query.filter_by(user_id=current_user.id, import_status="completed") \
        .order_by(ImportBatch.imported_at.desc()).limit(10).all()
    return render_template("imports/index.html", form=form, history=history)


@imports_bp.route("/<int:batch_id>/preview")
@login_required
def preview(batch_id):
    try:
        batch, rows, counts = ImportService.preview(current_user, batch_id)
    except LookupError:
        abort(404)
    except ImportError_ as e:
        flash(str(e), "danger")
        return redirect(url_for("imports.index"))
    return render_template("imports/preview.html", batch=batch, rows=rows[:300], total=len(rows),
                           counts=counts, action_form=FlaskForm())


@imports_bp.route("/<int:batch_id>/confirm", methods=["POST"])
@login_required
def confirm(batch_id):
    try:
        batch = ImportService.confirm(current_user, batch_id)
        flash("Imported %d record(s); skipped %d." % (batch.records_imported, batch.records_skipped), "success")
    except LookupError:
        abort(404)
    except ImportError_ as e:
        flash(str(e), "danger")
    return redirect(url_for("imports.index"))


@imports_bp.route("/<int:batch_id>/cancel", methods=["POST"])
@login_required
def cancel(batch_id):
    try:
        ImportService.cancel(current_user, batch_id)
    except LookupError:
        abort(404)
    return redirect(url_for("imports.index"))


@imports_bp.route("/sample.csv")
@login_required
def sample():
    return send_from_directory(current_app.static_folder, "sample_statement.csv", as_attachment=True)
