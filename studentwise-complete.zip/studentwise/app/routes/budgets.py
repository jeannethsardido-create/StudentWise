from flask import Blueprint, render_template, redirect, url_for, flash, request, abort
from flask_login import login_required, current_user
from sqlalchemy import or_
from app.forms.finance import BudgetForm
from app.models import Category
from app.services.budget_service import BudgetService, BudgetCalculationService, BudgetError

budget_bp = Blueprint("budgets", __name__, url_prefix="/budgets")


def _load_choices(form):
    cats = Category.query.filter(Category.category_type == "expense",
                                 or_(Category.user_id == current_user.id, Category.user_id.is_(None))) \
        .order_by(Category.name).all()
    form.category_id.choices = [(0, "-- all spending --")] + [(c.id, c.name) for c in cats]


@budget_bp.route("/")
@login_required
def index():
    return render_template("budgets/list.html", items=BudgetCalculationService.statuses_for_user(current_user.id))


@budget_bp.route("/new", methods=["GET", "POST"])
@login_required
def new():
    form = BudgetForm()
    _load_choices(form)
    if form.validate_on_submit():
        try:
            BudgetService.create(current_user, form.name.data, form.budget_amount.data, form.period_type.data,
                                 form.start_date.data, form.end_date.data, form.warning_threshold.data,
                                 form.category_id.data or None)
            flash("Budget saved.", "success")
            return redirect(url_for("budgets.index"))
        except BudgetError as e:
            flash(str(e), "danger")
    return render_template("budgets/form.html", form=form, title="Add budget")


@budget_bp.route("/<int:budget_id>/edit", methods=["GET", "POST"])
@login_required
def edit(budget_id):
    try:
        b = BudgetService.get_owned(current_user.id, budget_id)
    except LookupError:
        abort(404)
    form = BudgetForm(obj=b if request.method == "GET" else None)
    _load_choices(form)
    if request.method == "GET":
        form.category_id.data = b.category_id or 0
    if form.validate_on_submit():
        try:
            BudgetService.update(current_user, budget_id, form.name.data, form.budget_amount.data,
                                 form.period_type.data, form.start_date.data, form.end_date.data,
                                 form.warning_threshold.data, form.category_id.data or None)
            flash("Budget updated.", "success")
            return redirect(url_for("budgets.index"))
        except BudgetError as e:
            flash(str(e), "danger")
    return render_template("budgets/form.html", form=form, title="Edit budget")


@budget_bp.route("/<int:budget_id>/delete", methods=["POST"])
@login_required
def delete(budget_id):
    try:
        BudgetService.delete(current_user, budget_id)
        flash("Budget deleted.", "success")
    except LookupError:
        abort(404)
    return redirect(url_for("budgets.index"))
