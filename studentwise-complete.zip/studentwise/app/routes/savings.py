from flask import Blueprint, render_template, redirect, url_for, flash, request, abort
from flask_login import login_required, current_user
from app.forms.more import GoalForm, EntryForm
from app.services.savings_service import SavingsService, SavingsError

savings_bp = Blueprint("savings", __name__, url_prefix="/savings")


def _goal(goal_id):
    try:
        return SavingsService.get_owned(current_user.id, goal_id)
    except LookupError:
        abort(404)


@savings_bp.route("/")
@login_required
def index():
    return render_template("savings/list.html", items=SavingsService.all_progress(current_user.id),
                           totals=SavingsService.totals(current_user.id))


@savings_bp.route("/new", methods=["GET", "POST"])
@login_required
def new():
    form = GoalForm()
    if form.validate_on_submit():
        try:
            g = SavingsService.create(current_user, form.name.data, form.target_amount.data, form.target_date.data)
            flash("Goal created.", "success")
            return redirect(url_for("savings.detail", goal_id=g.id))
        except SavingsError as e:
            flash(str(e), "danger")
    return render_template("generic_form.html", form=form, title="New savings goal", cancel_url=url_for("savings.index"))


@savings_bp.route("/<int:goal_id>", methods=["GET", "POST"])
@login_required
def detail(goal_id):
    g = _goal(goal_id)
    form = EntryForm()
    if form.validate_on_submit():
        try:
            SavingsService.add_entry(current_user, goal_id, form.entry_type.data, form.amount.data,
                                     form.entry_date.data, form.notes.data)
            flash("Savings updated.", "success")
            return redirect(url_for("savings.detail", goal_id=goal_id))
        except SavingsError as e:
            flash(str(e), "danger")
    return render_template("savings/detail.html", p=SavingsService.progress(g), goal=g, form=form)


@savings_bp.route("/<int:goal_id>/edit", methods=["GET", "POST"])
@login_required
def edit(goal_id):
    g = _goal(goal_id)
    form = GoalForm(obj=g if request.method == "GET" else None)
    if form.validate_on_submit():
        try:
            SavingsService.update(current_user, goal_id, form.name.data, form.target_amount.data, form.target_date.data)
            flash("Goal updated.", "success")
            return redirect(url_for("savings.detail", goal_id=goal_id))
        except SavingsError as e:
            flash(str(e), "danger")
    return render_template("generic_form.html", form=form, title="Edit goal", cancel_url=url_for("savings.detail", goal_id=goal_id))


@savings_bp.route("/<int:goal_id>/complete", methods=["POST"])
@login_required
def complete(goal_id):
    _goal(goal_id)
    SavingsService.mark_completed(current_user, goal_id)
    flash("Goal marked as completed.", "success")
    return redirect(url_for("savings.detail", goal_id=goal_id))


@savings_bp.route("/<int:goal_id>/delete", methods=["POST"])
@login_required
def delete(goal_id):
    _goal(goal_id)
    SavingsService.delete(current_user, goal_id)
    flash("Goal deleted.", "success")
    return redirect(url_for("savings.index"))
