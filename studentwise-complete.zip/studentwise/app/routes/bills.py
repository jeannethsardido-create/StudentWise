import calendar
from datetime import date
from flask import Blueprint, render_template, redirect, url_for, flash, request, abort
from flask_login import login_required, current_user
from app.forms.more import BillForm, RecurringForm
from app.services.bill_service import BillService, RecurringService, BillError
from app.utils.choices import account_choices, category_choices

bills_bp = Blueprint("bills", __name__, url_prefix="/bills")
recurring_bp = Blueprint("recurring", __name__, url_prefix="/recurring")


def _month_arg():
    try:
        y, m = request.args.get("month", "").split("-")
        y, m = int(y), int(m)
        if 1 <= m <= 12 and 2000 <= y <= 2100:
            return y, m
    except ValueError:
        pass
    t = date.today()
    return t.year, t.month


def _shift(y, m, d):
    m += d
    return (y + 1, 1) if m > 12 else (y - 1, 12) if m < 1 else (y, m)


def _fill(form):
    form.category_id.choices = category_choices(current_user.id)
    form.account_id.choices = account_choices(current_user.id, allow_none=True)


@bills_bp.route("/")
@login_required
def index():
    RecurringService.generate_bills(current_user.id)
    y, m = _month_arg()
    bills = BillService.for_month(current_user.id, y, m)
    by_day = {}
    for b in bills:
        by_day.setdefault(b.due_date, []).append(b)
    py, pm = _shift(y, m, -1)
    ny, nm = _shift(y, m, 1)
    return render_template("bills/calendar.html", weeks=calendar.Calendar(6).monthdatescalendar(y, m),
                           by_day=by_day, bills=bills, year=y, month=m, today=date.today(),
                           month_name=date(y, m, 1).strftime("%B %Y"),
                           prev="%d-%02d" % (py, pm), next="%d-%02d" % (ny, nm),
                           unpaid_total=sum((b.amount for b in bills if b.status == "unpaid"), 0))


@bills_bp.route("/new", methods=["GET", "POST"])
@login_required
def new():
    form = BillForm()
    _fill(form)
    if form.validate_on_submit():
        try:
            BillService.create(current_user, form.name.data, form.amount.data, form.due_date.data,
                               form.category_id.data or None, form.account_id.data or None, form.notes.data)
            flash("Bill added.", "success")
            return redirect(url_for("bills.index", month=form.due_date.data.strftime("%Y-%m")))
        except BillError as e:
            flash(str(e), "danger")
    return render_template("generic_form.html", form=form, title="Add bill", cancel_url=url_for("bills.index"))


@bills_bp.route("/<int:bill_id>/edit", methods=["GET", "POST"])
@login_required
def edit(bill_id):
    try:
        b = BillService.get_owned(current_user.id, bill_id)
    except LookupError:
        abort(404)
    form = BillForm(obj=b if request.method == "GET" else None)
    _fill(form)
    if request.method == "GET":
        form.category_id.data, form.account_id.data = b.category_id or 0, b.account_id or 0
    if form.validate_on_submit():
        try:
            BillService.update(current_user, bill_id, form.name.data, form.amount.data, form.due_date.data,
                               form.category_id.data or None, form.account_id.data or None, form.notes.data)
            flash("Bill updated.", "success")
            return redirect(url_for("bills.index", month=form.due_date.data.strftime("%Y-%m")))
        except BillError as e:
            flash(str(e), "danger")
    return render_template("generic_form.html", form=form, title="Edit bill", cancel_url=url_for("bills.index"))


def _action(bill_id, fn, ok_msg):
    try:
        fn(current_user, bill_id)
        flash(ok_msg, "success")
    except LookupError:
        abort(404)
    except BillError as e:
        flash(str(e), "danger")
    return redirect(request.referrer or url_for("bills.index"))


@bills_bp.route("/<int:bill_id>/pay", methods=["POST"])
@login_required
def pay(bill_id):
    return _action(bill_id, BillService.mark_paid, "Marked as paid and recorded as an expense.")


@bills_bp.route("/<int:bill_id>/unpay", methods=["POST"])
@login_required
def unpay(bill_id):
    return _action(bill_id, BillService.mark_unpaid, "Payment undone.")


@bills_bp.route("/<int:bill_id>/delete", methods=["POST"])
@login_required
def delete(bill_id):
    return _action(bill_id, BillService.delete, "Bill deleted.")


# ---------------- recurring expenses ----------------
@recurring_bp.route("/")
@login_required
def index():
    from app.models import RecurringExpense
    items = RecurringExpense.query.filter_by(user_id=current_user.id).order_by(RecurringExpense.name).all()
    return render_template("recurring/list.html", items=items)


def _rec_form(r=None):
    form = RecurringForm(obj=r if (r and request.method == "GET") else None)
    _fill(form)
    if r and request.method == "GET":
        form.category_id.data, form.account_id.data = r.category_id or 0, r.account_id or 0
    return form


@recurring_bp.route("/new", methods=["GET", "POST"])
@login_required
def new():
    form = _rec_form()
    if form.validate_on_submit():
        try:
            RecurringService.create(current_user, form.name.data, form.amount.data, form.frequency.data,
                                    form.start_date.data, form.end_date.data, form.category_id.data or None,
                                    form.account_id.data or None)
            flash("Recurring expense added. Upcoming bills were created.", "success")
            return redirect(url_for("recurring.index"))
        except BillError as e:
            flash(str(e), "danger")
    return render_template("generic_form.html", form=form, title="Add recurring expense", cancel_url=url_for("recurring.index"))


@recurring_bp.route("/<int:rid>/edit", methods=["GET", "POST"])
@login_required
def edit(rid):
    try:
        r = RecurringService.get_owned(current_user.id, rid)
    except LookupError:
        abort(404)
    form = _rec_form(r)
    if form.validate_on_submit():
        try:
            RecurringService.update(current_user, rid, form.name.data, form.amount.data, form.frequency.data,
                                    form.start_date.data, form.end_date.data, form.category_id.data or None,
                                    form.account_id.data or None)
            flash("Recurring expense updated.", "success")
            return redirect(url_for("recurring.index"))
        except BillError as e:
            flash(str(e), "danger")
    return render_template("generic_form.html", form=form, title="Edit recurring expense", cancel_url=url_for("recurring.index"))


@recurring_bp.route("/<int:rid>/toggle", methods=["POST"])
@login_required
def toggle(rid):
    try:
        RecurringService.toggle(current_user, rid)
    except LookupError:
        abort(404)
    return redirect(url_for("recurring.index"))


@recurring_bp.route("/<int:rid>/delete", methods=["POST"])
@login_required
def delete(rid):
    try:
        RecurringService.delete(current_user, rid)
        flash("Recurring expense deleted.", "success")
    except LookupError:
        abort(404)
    return redirect(url_for("recurring.index"))
