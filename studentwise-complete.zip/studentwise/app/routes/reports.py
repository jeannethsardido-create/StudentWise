from datetime import date
from flask import Blueprint, render_template, request, Response
from flask_login import login_required, current_user
from app.services.budget_service import BudgetCalculationService as Calc
from app.services.export_service import ExportService
from app.services.report_service import FinancialReportService as Rpt
from app.services.savings_service import SavingsService
from app.utils.dates import resolve_period, parse_date

reports_bp = Blueprint("reports", __name__, url_prefix="/reports")
PALETTE = ["#6C63FF", "#2FA68B", "#4C8DF6", "#C26DD8", "#F2A03D", "#E8604C", "#4FC3F7", "#A3C94B", "#F06292", "#8D6E63"]


@reports_bp.route("/")
@login_required
def index():
    name, start, end = resolve_period(request.args.get("period", "month"), request.args.get("start"), request.args.get("end"))
    uid = current_user.id
    cats = Calc.category_breakdown(uid, start, end)
    daily = Rpt.daily_spending(uid, start, end)
    hist = Rpt.monthly_history(uid, 6)
    chart = {
        "cat": {"labels": [n for n, _ in cats], "values": [float(a) for _, a in cats],
                "colors": [PALETTE[i % len(PALETTE)] for i in range(len(cats))]},
        "daily": {"labels": [d.strftime("%b %d") for d, _ in daily], "values": [float(a) for _, a in daily]},
        "months": {"labels": [h["label"] for h in hist], "income": [float(h["income"]) for h in hist],
                   "expenses": [float(h["expenses"]) for h in hist]},
    }
    return render_template("reports/index.html", period=name, start=start, end=end,
                           totals=Calc.totals(uid, start, end), cats=cats, chart=chart,
                           accounts=Rpt.account_summary(uid, start, end),
                           budgets=Calc.statuses_for_user(uid), savings=SavingsService.all_progress(uid),
                           palette=PALETTE)


@reports_bp.route("/history")
@login_required
def history():
    rows = Rpt.monthly_history(current_user.id, 12)
    chart = {"labels": [r["label"] for r in rows], "income": [float(r["income"]) for r in rows],
             "expenses": [float(r["expenses"]) for r in rows]}
    return render_template("reports/history.html", rows=list(reversed(rows)), chart=chart)


@reports_bp.route("/export.csv")
@login_required
def export_csv():
    s, e = parse_date(request.args.get("start")), parse_date(request.args.get("end"))
    data = ExportService.transactions_csv(current_user.id, s, e)  # always limited to the logged-in user
    return Response(data, mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=studentwise-transactions.csv"})
