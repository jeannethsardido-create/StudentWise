from flask import Blueprint, render_template, redirect, url_for, abort, request
from flask_login import login_required, current_user
from flask_wtf import FlaskForm
from app.models import Notification
from app.services.notification_service import NotificationService as NS

notifications_bp = Blueprint("notifications", __name__, url_prefix="/notifications")

LINKS = {"bill": "bills.index", "budget": "budgets.index"}


@notifications_bp.route("/")
@login_required
def index():
    NS.generate_for_user(current_user)
    items = Notification.query.filter_by(user_id=current_user.id).order_by(Notification.created_at.desc()).limit(100).all()
    return render_template("notifications/index.html", items=items, links=LINKS, action_form=FlaskForm())


def _post(fn):
    if not FlaskForm().validate_on_submit():
        abort(400)
    try:
        fn()
    except LookupError:
        abort(404)
    return redirect(request.referrer or url_for("notifications.index"))


@notifications_bp.route("/<int:nid>/read", methods=["POST"])
@login_required
def read(nid):
    return _post(lambda: NS.mark_read(current_user.id, nid))


@notifications_bp.route("/read-all", methods=["POST"])
@login_required
def read_all():
    return _post(lambda: NS.mark_all_read(current_user.id))


@notifications_bp.route("/<int:nid>/delete", methods=["POST"])
@login_required
def delete(nid):
    return _post(lambda: NS.dismiss(current_user.id, nid))
