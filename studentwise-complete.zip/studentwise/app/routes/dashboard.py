from datetime import datetime, date
from flask import Blueprint, render_template, redirect, url_for, request, jsonify
from flask_login import login_required, current_user
from app.services.budget_service import BudgetCalculationService as Calc
from app.services.transaction_service import TransactionService
from app.services.bill_service import BillService, RecurringService
from app.services.savings_service import SavingsService
from app.utils.money import peso
from app.services.notification_service import NotificationService
from app.utils.dates import resolve_period

dashboard_bp = Blueprint("dashboard", __name__)
PALETTE = ["#6C63FF", "#2FA68B", "#4C8DF6", "#C26DD8", "#F2A03D", "#E8604C", "#4FC3F7", "#A3C94B", "#F06292", "#8D6E63"]


def _period():
    return resolve_period(request.args.get("period", "month"), request.args.get("start"), request.args.get("end"))


def _greeting():
    h = datetime.now().hour
    return "Good morning" if h < 12 else "Good afternoon" if h < 18 else "Good evening"


@dashboard_bp.route("/")
def home():
    return redirect(url_for("dashboard.index"))


@dashboard_bp.route("/dashboard")
@login_required
def index():
    name, start, end = _period()
    RecurringService.generate_bills(current_user.id)
    NotificationService.generate_for_user(current_user)
    summary = Calc.dashboard_summary(current_user.id, start, end)
    statuses = Calc.statuses_for_user(current_user.id)
    bills = BillService.summary(current_user.id)
    alerts = Calc.pace_alerts(statuses)
    for b in bills["overdue"]:
        alerts.append("%s (%s) is overdue since %s." % (b.name, peso(b.amount), b.due_date.strftime("%b %d")))
    rows = Calc.category_breakdown(current_user.id, start, end)
    total = sum((a for _, a in rows), 0)
    donut = [{"name": n, "amount": a, "percent": round(float(a / total * 100)) if total else 0,
              "color": PALETTE[i % len(PALETTE)]} for i, (n, a) in enumerate(rows)]
    chart = {"labels": [d["name"] for d in donut], "values": [float(d["amount"]) for d in donut],
             "colors": [d["color"] for d in donut]}
    return render_template(
        "dashboard/index.html", user=current_user, summary=summary, period=name, start=start, end=end,
        greeting=_greeting(), today_date=date.today(), alerts=alerts, statuses=statuses, bills=bills,
        upcoming=BillService.upcoming(current_user.id, days=30, limit=5), savings=SavingsService.totals(current_user.id),
        goals=SavingsService.all_progress(current_user.id)[:3],
        donut=donut, donut_total=total, chart=chart,
        recent=TransactionService.search(current_user.id, limit=6),
        balances=Calc.account_balances(current_user.id))


@dashboard_bp.route("/api/dashboard")
@login_required
def api_dashboard():
    """Backend is the source of truth; JS only displays what this returns."""
    name, start, end = _period()
    data = Calc.format_summary(Calc.dashboard_summary(current_user.id, start, end))
    data.update(period=name, start=start.isoformat(), end=end.isoformat())
    return jsonify(data)
