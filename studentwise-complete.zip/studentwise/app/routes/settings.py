from datetime import date
from flask import Blueprint, render_template, redirect, url_for, flash, abort, Response
from flask_login import login_required, current_user, logout_user
from flask_wtf import FlaskForm
from app.forms.more import ProfileForm, PasswordForm, AccountForm, DeleteForm, NotifyForm
from app.extensions import db
from app.services.notification_service import NotificationService, normalize_phone
from app.models import Account
from app.services.account_service import AccountService, UserService, SettingsError
from app.services.export_service import ExportService

settings_bp = Blueprint("settings", __name__, url_prefix="/settings")


@settings_bp.route("/")
@login_required
def index():
    return render_template("settings/index.html",
                           profile=ProfileForm(prefix="p", name=current_user.name),
                           password=PasswordForm(prefix="pw"),
                           notify=NotifyForm(prefix="n", phone=current_user.phone, notify_email=current_user.notify_email,
                                             notify_sms=current_user.notify_sms),
                           channels=NotificationService.channel_status(), account=AccountForm(prefix="a"),
                           delete=DeleteForm(prefix="d"), action_form=FlaskForm(),
                           accounts=Account.query.filter_by(user_id=current_user.id).order_by(Account.account_name).all())


def _back():
    return redirect(url_for("settings.index"))


def _errors(form):
    for errs in form.errors.values():
        for e in errs:
            flash(e, "danger")
    return _back()


@settings_bp.route("/profile", methods=["POST"])
@login_required
def profile():
    f = ProfileForm(prefix="p")
    if not f.validate_on_submit():
        return _errors(f)
    try:
        UserService.update_name(current_user, f.name.data)
        flash("Name updated.", "success")
    except SettingsError as e:
        flash(str(e), "danger")
    return _back()


@settings_bp.route("/password", methods=["POST"])
@login_required
def password():
    f = PasswordForm(prefix="pw")
    if not f.validate_on_submit():
        return _errors(f)
    try:
        UserService.change_password(current_user, f.current.data, f.new.data)
        flash("Password changed.", "success")
    except SettingsError as e:
        flash(str(e), "danger")
    return _back()


@settings_bp.route("/accounts/new", methods=["POST"])
@login_required
def account_new():
    f = AccountForm(prefix="a")
    if not f.validate_on_submit():
        return _errors(f)
    try:
        AccountService.add_account(current_user, f.account_name.data, f.account_type.data, f.provider.data)
        flash("Account added. Balances here are user-entered estimates.", "success")
    except SettingsError as e:
        flash(str(e), "danger")
    return _back()


@settings_bp.route("/accounts/<int:account_id>/delete", methods=["POST"])
@login_required
def account_delete(account_id):
    f = FlaskForm()
    if not f.validate_on_submit():
        abort(400)
    try:
        AccountService.delete_account(current_user, account_id)
        flash("Account deleted.", "success")
    except LookupError:
        abort(404)
    except SettingsError as e:
        flash(str(e), "danger")
    return _back()


@settings_bp.route("/export.csv")
@login_required
def export_csv():
    return Response(ExportService.transactions_csv(current_user.id), mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=studentwise-all-transactions.csv"})


@settings_bp.route("/backup.json")
@login_required
def backup():
    name = "studentwise-backup-%s.json" % date.today().isoformat()
    return Response(ExportService.backup_json(current_user), mimetype="application/json",
                    headers={"Content-Disposition": "attachment; filename=" + name})


@settings_bp.route("/delete", methods=["POST"])
@login_required
def delete():
    f = DeleteForm(prefix="d")
    if not f.validate_on_submit():
        return _errors(f)
    try:
        UserService.delete_user(current_user, f.password.data)
    except SettingsError as e:
        flash(str(e), "danger")
        return _back()
    logout_user()
    flash("Your account and all its records were deleted.", "success")
    return redirect(url_for("auth.login"))


@settings_bp.route("/notifications", methods=["POST"])
@login_required
def notifications():
    f = NotifyForm(prefix="n")
    if not f.validate_on_submit():
        return _errors(f)
    phone = None
    if f.phone.data and f.phone.data.strip():
        phone = normalize_phone(f.phone.data)
        if phone is None:
            flash("Enter a valid Philippine mobile number, like 09171234567.", "danger")
            return _back()
    if f.notify_sms.data and not phone:
        flash("Add your mobile number to turn on text alerts.", "danger")
        return _back()
    current_user.phone, current_user.notify_email, current_user.notify_sms = phone, f.notify_email.data, f.notify_sms.data
    db.session.commit()
    flash("Alert settings saved.", "success")
    return _back()


@settings_bp.route("/notifications/test", methods=["POST"])
@login_required
def notifications_test():
    if not FlaskForm().validate_on_submit():
        abort(400)
    n = NotificationService.send_test(current_user)
    labels = {"sent": "sent", "failed": "FAILED (check your settings)", "not_configured": "not set up on this server",
              "off": "turned off"}
    flash("Test created. Email: %s. Text: %s." % (labels.get(n.email_status, n.email_status),
                                                  labels.get(n.sms_status, n.sms_status)),
          "success" if "sent" in (n.email_status, n.sms_status) else "warning")
    return _back()
