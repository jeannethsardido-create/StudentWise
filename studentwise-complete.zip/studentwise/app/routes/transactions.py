from flask import Blueprint, render_template, redirect, url_for, flash, request, abort
from flask_login import login_required, current_user
from app.forms.finance import TransactionForm
from app.models import Account, Category
from app.services.transaction_service import TransactionService, TransactionError
from app.utils.dates import parse_date
from sqlalchemy import or_

tx_bp = Blueprint("transactions", __name__, url_prefix="/transactions")


def _load_choices(form):
    form.account_id.choices = [(a.id, a.account_name) for a in
                               Account.query.filter_by(user_id=current_user.id).order_by(Account.account_name)]
    cats = Category.query.filter(or_(Category.user_id == current_user.id, Category.user_id.is_(None))) \
        .order_by(Category.category_type, Category.name).all()
    form.category_id.choices = [(0, "-- none --")] + [(c.id, "%s (%s)" % (c.name, c.category_type)) for c in cats]


@tx_bp.route("/")
@login_required
def index():
    category_id = request.args.get("category_id", type=int)
    txs = TransactionService.search(
        current_user.id, q=request.args.get("q"), tx_type=request.args.get("type"),
        category_id=category_id, start=parse_date(request.args.get("start")),
        end=parse_date(request.args.get("end")), sort=request.args.get("sort", "date_desc"))
    cats = Category.query.filter(or_(Category.user_id == current_user.id, Category.user_id.is_(None))) \
        .order_by(Category.name).all()
    return render_template("transactions/list.html", txs=txs, cats=cats, args=request.args)


@tx_bp.route("/new", methods=["GET", "POST"])
@login_required
def new():
    form = TransactionForm()
    _load_choices(form)
    if request.method == "GET":
        form.transaction_type.data = request.args.get("type", "expense")
    if form.validate_on_submit():
        try:
            TransactionService.create(
                current_user, form.transaction_type.data, form.description.data, form.amount.data,
                form.account_id.data, form.category_id.data or None, form.transaction_date.data,
                form.status.data, form.notes.data)
            flash("Record saved.", "success")
            return redirect(url_for("transactions.index"))
        except TransactionError as e:
            flash(str(e), "danger")
    return render_template("transactions/form.html", form=form, title="Add record", editing=False)


@tx_bp.route("/<int:tx_id>/edit", methods=["GET", "POST"])
@login_required
def edit(tx_id):
    try:
        tx = TransactionService.get_owned(current_user.id, tx_id)
    except LookupError:
        abort(404)
    form = TransactionForm(obj=tx if request.method == "GET" else None)
    del form.transaction_type  # type cannot change after creation
    _load_choices(form)
    if request.method == "GET":
        form.category_id.data = tx.category_id or 0
        form.transaction_date.data = tx.transaction_date.date()
    if form.validate_on_submit():
        try:
            TransactionService.update(
                current_user, tx_id, form.description.data, form.amount.data, form.account_id.data,
                form.category_id.data or None, form.transaction_date.data, form.status.data, form.notes.data)
            flash("Record updated.", "success")
            return redirect(url_for("transactions.index"))
        except TransactionError as e:
            flash(str(e), "danger")
    return render_template("transactions/form.html", form=form, title="Edit record", editing=True)


@tx_bp.route("/<int:tx_id>/delete", methods=["POST"])
@login_required
def delete(tx_id):
    try:
        TransactionService.delete(current_user, tx_id)
        flash("Record deleted.", "success")
    except LookupError:
        abort(404)
    except TransactionError as e:
        flash(str(e), "danger")
    return redirect(url_for("transactions.index"))
