from flask import Flask, render_template, flash, redirect, request, url_for
from config import Config
from app.extensions import db, migrate, login_manager, csrf
from app.utils.money import peso


def create_app(config_class=Config):
    config_class.validate()
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_object(config_class)

    db.init_app(app)
    migrate.init_app(app, db)
    login_manager.init_app(app)
    csrf.init_app(app)
    app.add_template_filter(peso, "peso")

    from app import models  # noqa: F401
    from app.routes.auth import auth_bp
    from app.routes.dashboard import dashboard_bp
    from app.routes.transactions import tx_bp
    from app.routes.budgets import budget_bp
    from app.routes.bills import bills_bp, recurring_bp
    from app.routes.savings import savings_bp
    from app.routes.reports import reports_bp
    from app.routes.imports import imports_bp
    from app.routes.settings import settings_bp
    from app.routes.notifications import notifications_bp

    for bp in (auth_bp, dashboard_bp, tx_bp, budget_bp, bills_bp, recurring_bp, savings_bp,
               reports_bp, imports_bp, settings_bp, notifications_bp):
        app.register_blueprint(bp)

    @app.errorhandler(404)
    def not_found(e):
        return render_template("error.html", code=404, message="Page not found."), 404

    from flask_login import current_user
    from flask_wtf.csrf import CSRFError
    from app.services.notification_service import NotificationService

    @app.context_processor
    def inject_unread():
        if current_user.is_authenticated:
            return {"unread_notifications": NotificationService.unread_count(current_user.id)}
        return {"unread_notifications": 0}

    @app.errorhandler(CSRFError)
    def csrf_expired(e):
        flash("Your page expired. Please try again.", "warning")
        return redirect(request.referrer or url_for("auth.login"))

    @app.cli.command("send-reminders")
    def send_reminders():
        """Create (and email/text) due-bill and budget alerts for every user."""
        print("New alerts created:", NotificationService.send_reminders_for_all())

    @app.errorhandler(413)
    def too_large(e):
        return render_template("error.html", code=413, message="That file is too large (limit 1 MB)."), 413

    @app.errorhandler(500)
    def server_error(e):
        db.session.rollback()
        return render_template("error.html", code=500, message="Something went wrong."), 500

    return app
