import re
import smtplib
import ssl
import urllib.parse
import urllib.request
from abc import ABC, abstractmethod
from datetime import date, timedelta
from email.message import EmailMessage
from flask import current_app
from sqlalchemy.exc import IntegrityError, SQLAlchemyError
from app.extensions import db
from app.models import Notification, User
from app.services.bill_service import BillService
from app.services.budget_service import BudgetCalculationService as Calc
from app.utils.money import peso

PH_MOBILE = re.compile(r"^(?:\+?63|0)(9\d{9})$")
TIMEOUT = 8  # seconds; a slow provider can never hang the app for long


def normalize_phone(text):
    """Return a Philippine mobile number as 09XXXXXXXXX, or None if it isn't one."""
    m = PH_MOBILE.match((text or "").replace(" ", "").replace("-", ""))
    return "0" + m.group(1) if m else None


class AbstractNotificationProvider(ABC):
    """Each delivery channel implements the same interface (polymorphism)."""
    channel = ""

    @abstractmethod
    def is_configured(self) -> bool: ...

    @abstractmethod
    def send(self, user, title, message) -> str:
        """Return 'sent' or raise an exception. Never include secrets in the exception text."""


class EmailProvider(AbstractNotificationProvider):
    channel = "email"

    def is_configured(self):
        c = current_app.config
        return bool(c["MAIL_SERVER"] and c["MAIL_USERNAME"] and c["MAIL_PASSWORD"])

    def send(self, user, title, message):
        c = current_app.config
        msg = EmailMessage()
        msg["Subject"] = "StudentWise: " + title
        msg["From"] = c["MAIL_FROM"] or c["MAIL_USERNAME"]
        msg["To"] = user.email
        msg.set_content("Hi %s,\n\n%s\n\n- StudentWise\n(You can turn these emails off in Settings & Data.)"
                        % (user.name.split()[0], message))
        ctx = ssl.create_default_context()
        if c["MAIL_PORT"] == 465:
            server = smtplib.SMTP_SSL(c["MAIL_SERVER"], 465, timeout=TIMEOUT, context=ctx)
        else:
            server = smtplib.SMTP(c["MAIL_SERVER"], c["MAIL_PORT"], timeout=TIMEOUT)
            server.starttls(context=ctx)
        try:
            server.login(c["MAIL_USERNAME"], c["MAIL_PASSWORD"])
            server.send_message(msg)
        finally:
            server.quit()
        return "sent"


class SemaphoreSMSProvider(AbstractNotificationProvider):
    channel = "sms"
    URL = "https://api.semaphore.co/api/v4/messages"

    def is_configured(self):
        return bool(current_app.config["SEMAPHORE_API_KEY"])

    def send(self, user, title, message):
        number = normalize_phone(user.phone)
        if not number:
            raise ValueError("invalid phone")
        c = current_app.config
        fields = {"apikey": c["SEMAPHORE_API_KEY"], "number": number,
                  "message": ("StudentWise: " + message)[:300]}
        if c["SEMAPHORE_SENDER_NAME"]:
            fields["sendername"] = c["SEMAPHORE_SENDER_NAME"]
        req = urllib.request.Request(self.URL, data=urllib.parse.urlencode(fields).encode())
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            if resp.status >= 300:
                raise RuntimeError("SMS provider error")
        return "sent"


class NotificationService:
    email = EmailProvider()
    sms = SemaphoreSMSProvider()

    # ---------- delivery ----------
    @classmethod
    def _deliver(cls, provider, enabled, user, title, message):
        if not enabled:
            return "off"
        if not provider.is_configured():
            return "not_configured"
        try:
            return provider.send(user, title, message)
        except Exception as exc:  # log the error TYPE only: no tokens, passwords or message bodies
            current_app.logger.warning("%s delivery failed: %s", provider.channel, type(exc).__name__)
            return "failed"

    @classmethod
    def create(cls, user, title, message, ntype, related_type=None, related_id=None, dedupe_key=None, send=True):
        n = Notification(user_id=user.id, title=title, message=message, notification_type=ntype,
                         related_record_type=related_type, related_record_id=related_id,
                         dedupe_key=dedupe_key or "%s:%s" % (ntype, related_id))
        try:
            db.session.add(n)
            db.session.commit()
        except IntegrityError:          # already notified about this event
            db.session.rollback()
            return None
        if send:
            n.email_status = cls._deliver(cls.email, user.notify_email, user, title, message)
            n.sms_status = cls._deliver(cls.sms, user.notify_sms and bool(user.phone), user, title, message)
            try:
                db.session.commit()
            except SQLAlchemyError:
                db.session.rollback()
        return n

    # ---------- what deserves an alert ----------
    @classmethod
    def generate_for_user(cls, user, today=None):
        today = today or date.today()
        made = 0
        for b in BillService.upcoming(user.id, today, days=3):
            if b.due_date < today:
                n = cls.create(user, "Bill overdue: " + b.name,
                               "%s (%s) was due on %s and is still unpaid." % (b.name, peso(b.amount), b.due_date.strftime("%b %d")),
                               "bill_overdue", "bill", b.id, "bill:%d:overdue:%s" % (b.id, b.due_date))
            else:
                when = "today" if b.due_date == today else "on " + b.due_date.strftime("%b %d")
                n = cls.create(user, "Bill due soon: " + b.name,
                               "%s (%s) is due %s." % (b.name, peso(b.amount), when),
                               "bill_due", "bill", b.id, "bill:%d:due:%s" % (b.id, b.due_date))
            made += 1 if n else 0
        for s in Calc.statuses_for_user(user.id):
            b = s["budget"]
            if not (b.start_date <= today <= b.end_date) or s["level"] == "ok":
                continue
            if s["level"] == "exceeded":
                n = cls.create(user, "Budget exceeded: " + b.name,
                               "You've used %s%% of your %s budget (%s of %s)." % (s["percent"], b.name, peso(s["spent"]), peso(b.budget_amount)),
                               "budget_exceeded", "budget", b.id, "budget:%d:exceeded" % b.id)
            else:
                n = cls.create(user, "Budget warning: " + b.name,
                               "You've used %s%% of your %s budget. %s left." % (s["percent"], b.name, peso(s["remaining"])),
                               "budget_warning", "budget", b.id, "budget:%d:warning" % b.id)
            made += 1 if n else 0
        return made

    @classmethod
    def send_test(cls, user):
        stamp = date.today().isoformat() + ":" + str(Notification.query.filter_by(user_id=user.id).count())
        return cls.create(user, "Test notification", "This is a test from StudentWise. Your alerts are working.",
                          "test", dedupe_key="test:" + stamp)

    @classmethod
    def channel_status(cls):
        return {"email": cls.email.is_configured(), "sms": cls.sms.is_configured()}

    # ---------- in-app center ----------
    @staticmethod
    def unread_count(user_id):
        return Notification.query.filter_by(user_id=user_id, is_read=False).count()

    @staticmethod
    def get_owned(user_id, nid):
        n = Notification.query.filter_by(id=nid, user_id=user_id).first()
        if n is None:
            raise LookupError("Notification not found")
        return n

    @classmethod
    def mark_read(cls, user_id, nid):
        cls.get_owned(user_id, nid).is_read = True
        db.session.commit()

    @staticmethod
    def mark_all_read(user_id):
        Notification.query.filter_by(user_id=user_id, is_read=False).update({"is_read": True})
        db.session.commit()

    @classmethod
    def dismiss(cls, user_id, nid):
        db.session.delete(cls.get_owned(user_id, nid))
        db.session.commit()

    @staticmethod
    def send_reminders_for_all(today=None):
        """Used by `flask send-reminders`; schedule it daily for alerts when the website isn't open."""
        total = 0
        for user in User.query.all():
            total += NotificationService.generate_for_user(user, today)
        return total
