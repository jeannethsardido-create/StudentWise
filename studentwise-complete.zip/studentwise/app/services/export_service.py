import csv
import io
import json
from datetime import date, datetime
from decimal import Decimal
from app.models import (Transaction, Budget, Bill, RecurringExpense, SavingsGoal, Account)
from app.services.transaction_service import TransactionService

_DANGEROUS = ("=", "+", "-", "@", "\t", "\r")


def safe_cell(value):
    """Stop spreadsheet formula injection: text starting with = + - @ is prefixed with a quote."""
    text = "" if value is None else str(value)
    return "'" + text if text.startswith(_DANGEROUS) else text


class ExportService:
    @staticmethod
    def transactions_csv(user_id, start=None, end=None):
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["date", "type", "description", "amount", "category", "account", "status", "source", "notes"])
        for t in TransactionService.search(user_id, start=start, end=end, sort="date_asc", limit=100000):
            w.writerow([t.transaction_date.strftime("%Y-%m-%d"), t.transaction_type, safe_cell(t.description),
                        "%.2f" % t.amount, safe_cell(t.category.name if t.category else ""),
                        safe_cell(t.account.account_name), t.status, t.source, safe_cell(t.notes)])
        return buf.getvalue()

    @staticmethod
    def _plain(v):
        if isinstance(v, (date, datetime)):
            return v.isoformat()
        if isinstance(v, Decimal):
            return str(v)
        return v

    @classmethod
    def backup_json(cls, user):
        def rows(model, fields):
            return [{f: cls._plain(getattr(r, f)) for f in fields} for r in model.query.filter_by(user_id=user.id)]
        data = {
            "exported_at": datetime.now().isoformat(timespec="seconds"),
            "user": {"name": user.name, "email": user.email},
            "accounts": rows(Account, ["id", "account_name", "account_type", "provider"]),
            "transactions": rows(Transaction, ["id", "transaction_type", "description", "amount", "category_id",
                                               "account_id", "transaction_date", "status", "source", "notes"]),
            "budgets": rows(Budget, ["name", "budget_amount", "category_id", "start_date", "end_date",
                                     "warning_threshold"]),
            "bills": rows(Bill, ["name", "amount", "due_date", "status", "paid_date"]),
            "recurring_expenses": rows(RecurringExpense, ["name", "amount", "frequency", "start_date", "end_date",
                                                          "active"]),
            "savings_goals": [dict({f: cls._plain(getattr(g, f)) for f in
                                    ["name", "target_amount", "target_date", "status"]},
                                   entries=[{f: cls._plain(getattr(e, f)) for f in
                                             ["entry_type", "amount", "entry_date", "notes"]} for e in g.entries])
                              for g in SavingsGoal.query.filter_by(user_id=user.id)],
        }
        return json.dumps(data, indent=2)
