from datetime import date
from decimal import Decimal
from sqlalchemy import func
from sqlalchemy.exc import SQLAlchemyError
from app.extensions import db
from app.models import Transaction, Budget, Category, Account
from app.utils.money import to_decimal, peso
from app.utils.dates import day_start, day_end_exclusive

ZERO = Decimal("0.00")


class BudgetError(ValueError):
    pass


class BudgetCalculationService:
    """Authoritative money math. Only COMPLETED income/expense records count;
    pending, failed and reversed records are ignored; transfers are excluded."""

    @staticmethod
    def _sum(user_id, tx_type, start=None, end=None, category_id=None):
        q = db.session.query(func.coalesce(func.sum(Transaction.amount), 0)).filter(
            Transaction.user_id == user_id,
            Transaction.transaction_type == tx_type,
            Transaction.status == "completed",
        )
        if start:
            q = q.filter(Transaction.transaction_date >= day_start(start))
        if end:
            q = q.filter(Transaction.transaction_date < day_end_exclusive(end))
        if category_id:
            q = q.filter(Transaction.category_id == category_id)
        return to_decimal(q.scalar())

    @classmethod
    def totals(cls, user_id, start, end):
        income = cls._sum(user_id, "income", start, end)
        expenses = cls._sum(user_id, "expense", start, end)
        return {"income": income, "expenses": expenses, "net": income - expenses}

    @classmethod
    def available_balance(cls, user_id):
        """All-time completed income minus expenses. Transfers net to zero overall,
        so money moved between accounts is never counted twice."""
        return cls._sum(user_id, "income") - cls._sum(user_id, "expense")

    @staticmethod
    def account_balances(user_id):
        result = []
        for acc in Account.query.filter_by(user_id=user_id).order_by(Account.account_name):
            bal = sum((t.signed_amount() for t in acc.transactions if t.counts_as_completed()), ZERO)
            result.append({"name": acc.account_name, "type": acc.account_type, "balance": to_decimal(bal)})
        return result

    @staticmethod
    def category_breakdown(user_id, start, end):
        rows = (
            db.session.query(Category.name, func.sum(Transaction.amount))
            .outerjoin(Category, Transaction.category_id == Category.id)
            .filter(Transaction.user_id == user_id, Transaction.transaction_type == "expense",
                    Transaction.status == "completed",
                    Transaction.transaction_date >= day_start(start),
                    Transaction.transaction_date < day_end_exclusive(end))
            .group_by(Category.name).all()
        )
        return sorted(((n or "Uncategorized", to_decimal(a)) for n, a in rows), key=lambda r: -r[1])

    @classmethod
    def budget_status(cls, budget):
        spent = cls._sum(budget.user_id, "expense", budget.start_date, budget.end_date, budget.category_id)
        limit = to_decimal(budget.budget_amount)
        remaining = limit - spent
        if limit == 0:  # safe zero-budget handling
            percent = Decimal("100.0") if spent > 0 else Decimal("0.0")
        else:
            percent = (spent / limit * 100).quantize(Decimal("0.1"))
        if percent >= 100:
            level, label = "exceeded", "Over budget (%s%% used)" % percent
        elif percent >= budget.warning_threshold:
            level, label = "warning", "Warning: %s%% used" % percent
        else:
            level, label = "ok", "On track (%s%% used)" % percent
        return {"budget": budget, "spent": spent, "remaining": remaining,
                "percent": percent, "bar": min(percent, Decimal("100")), "level": level, "label": label}

    @classmethod
    def statuses_for_user(cls, user_id):
        budgets = Budget.query.filter_by(user_id=user_id).order_by(Budget.start_date.desc()).all()
        return [cls.budget_status(b) for b in budgets]

    @classmethod
    def dashboard_summary(cls, user_id, start, end, today=None):
        today = today or date.today()
        t = cls.totals(user_id, start, end)
        active = [s for s in cls.statuses_for_user(user_id)
                  if s["budget"].start_date <= today <= s["budget"].end_date]
        remaining_budget = sum((s["remaining"] for s in active), ZERO)
        overall = [s for s in active if s["budget"].category_id is None]
        budgeted = sum((to_decimal(s["budget"].budget_amount) for s in (overall or active)), ZERO)
        used = (t["expenses"] / budgeted * 100).quantize(Decimal("0.1")) if budgeted > 0 else Decimal("0.0")
        return {
            "balance": cls.available_balance(user_id),
            "income": t["income"], "expenses": t["expenses"],
            "remaining_budget": remaining_budget, "budgeted": budgeted,
            "used_percent": used, "active_budgets": len(active),
        }

    @staticmethod
    def pace_alerts(statuses, today=None):
        """'Heads up' messages: already over budget, or projected to go over at the current pace."""
        today = today or date.today()
        alerts = []
        for s in statuses:
            b = s["budget"]
            if not (b.start_date <= today <= b.end_date) or s["spent"] <= 0:
                continue
            limit = to_decimal(b.budget_amount)
            if s["level"] == "exceeded":
                alerts.append("%s is already over budget by %s." % (b.name, peso(s["spent"] - limit)))
                continue
            elapsed = max(1, (today - b.start_date).days + 1)
            total = (b.end_date - b.start_date).days + 1
            projected = to_decimal(s["spent"] / elapsed * total)
            if projected > limit:
                alerts.append("At this pace, %s may finish around %s - about %s over budget."
                              % (b.name, peso(projected), peso(projected - limit)))
        return alerts

    @staticmethod
    def format_summary(summary):
        out = {k: peso(v) for k, v in summary.items() if k not in ("active_budgets", "used_percent")}
        out["active_budgets"] = summary["active_budgets"]
        out["used_percent"] = str(summary["used_percent"])
        return out


class BudgetService:
    @staticmethod
    def get_owned(user_id, budget_id):
        b = Budget.query.filter_by(id=budget_id, user_id=user_id).first()
        if b is None:
            raise LookupError("Budget not found")
        return b

    @staticmethod
    def _validate(user_id, name, amount, start, end, threshold, category_id):
        if not (name or "").strip():
            raise BudgetError("Budget name is required.")
        amount = to_decimal(amount)
        if amount < 0:
            raise BudgetError("Budget amount cannot be negative.")
        if not start or not end or end < start:
            raise BudgetError("End date must be on or after the start date.")
        if not 1 <= int(threshold) <= 100:
            raise BudgetError("Warning threshold must be between 1 and 100.")
        if category_id:
            cat = Category.query.filter(Category.id == category_id).filter(
                (Category.user_id == user_id) | (Category.user_id.is_(None))).first()
            if cat is None or cat.category_type != "expense":
                raise BudgetError("Choose a valid expense category.")
        return amount

    @classmethod
    def create(cls, user, name, amount, period_type, start, end, threshold, category_id=None):
        amount = cls._validate(user.id, name, amount, start, end, threshold, category_id)
        try:
            b = Budget(user_id=user.id, name=name.strip(), budget_amount=amount, period_type=period_type,
                       start_date=start, end_date=end, warning_threshold=int(threshold),
                       category_id=category_id or None)
            db.session.add(b)
            db.session.commit()
            return b
        except SQLAlchemyError:
            db.session.rollback()
            raise BudgetError("Could not save the budget.")

    @classmethod
    def update(cls, user, budget_id, name, amount, period_type, start, end, threshold, category_id=None):
        b = cls.get_owned(user.id, budget_id)
        amount = cls._validate(user.id, name, amount, start, end, threshold, category_id)
        try:
            b.name, b.budget_amount, b.period_type = name.strip(), amount, period_type
            b.start_date, b.end_date, b.warning_threshold = start, end, int(threshold)
            b.category_id = category_id or None
            db.session.commit()
            return b
        except SQLAlchemyError:
            db.session.rollback()
            raise BudgetError("Could not update the budget.")

    @classmethod
    def delete(cls, user, budget_id):
        b = cls.get_owned(user.id, budget_id)
        db.session.delete(b)
        db.session.commit()
