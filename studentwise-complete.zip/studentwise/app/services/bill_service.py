import calendar
from datetime import date, timedelta
from sqlalchemy.exc import SQLAlchemyError
from app.extensions import db
from app.models import Bill, RecurringExpense, ExpenseTransaction, Account
from app.services.transaction_service import TransactionService as TS, TransactionError
from app.utils.dates import day_start
from app.utils.money import to_decimal


class BillError(ValueError):
    pass


def _check_common(user_id, name, amount, category_id, account_id):
    if not (name or "").strip():
        raise BillError("Name is required.")
    try:
        amt = TS._clean_amount(amount)
        if account_id:
            TS._owned_account(user_id, account_id)
        TS._visible_category(user_id, category_id, "expense")
    except TransactionError as e:
        raise BillError(str(e))
    return amt


class BillService:
    @staticmethod
    def get_owned(user_id, bill_id):
        b = Bill.query.filter_by(id=bill_id, user_id=user_id).first()
        if b is None:
            raise LookupError("Bill not found")
        return b

    @classmethod
    def create(cls, user, name, amount, due_date, category_id=None, account_id=None, notes=None):
        amt = _check_common(user.id, name, amount, category_id, account_id)
        if not due_date:
            raise BillError("Due date is required.")
        try:
            b = Bill(user_id=user.id, name=name.strip(), amount=amt, due_date=due_date,
                     category_id=category_id or None, account_id=account_id or None, notes=notes)
            db.session.add(b)
            db.session.commit()
            return b
        except SQLAlchemyError:
            db.session.rollback()
            raise BillError("Could not save the bill.")

    @classmethod
    def update(cls, user, bill_id, name, amount, due_date, category_id=None, account_id=None, notes=None):
        b = cls.get_owned(user.id, bill_id)
        if b.status == "paid":
            raise BillError("A paid bill can't be edited. Mark it unpaid first.")
        amt = _check_common(user.id, name, amount, category_id, account_id)
        try:
            b.name, b.amount, b.due_date = name.strip(), amt, due_date  # moving the date never creates a transaction
            b.category_id, b.account_id, b.notes = category_id or None, account_id or None, notes
            db.session.commit()
            return b
        except SQLAlchemyError:
            db.session.rollback()
            raise BillError("Could not update the bill.")

    @classmethod
    def delete(cls, user, bill_id):
        b = cls.get_owned(user.id, bill_id)
        db.session.delete(b)  # deleting a bill leaves any expense it created untouched
        db.session.commit()

    @classmethod
    def mark_paid(cls, user, bill_id, today=None):
        b = cls.get_owned(user.id, bill_id)
        if b.status == "paid":
            raise BillError("This bill is already paid.")
        acc_id = b.account_id
        if not acc_id:
            first = Account.query.filter_by(user_id=user.id).order_by(Account.id).first()
            acc_id = first.id if first else None
        if not acc_id:
            raise BillError("Add an account first.")
        today = today or date.today()
        try:
            TS._owned_account(user.id, acc_id)
            tx = ExpenseTransaction(user_id=user.id, account_id=acc_id, description=b.name, amount=b.amount,
                                    category_id=b.category_id, transaction_date=day_start(today),
                                    status="completed", source="manual", notes="Paid from bill")
            db.session.add(tx)
            db.session.flush()
            b.paid_transaction_id, b.status, b.paid_date = tx.id, "paid", today
            db.session.commit()  # expense + bill status change together, or not at all
        except (SQLAlchemyError, TransactionError):
            db.session.rollback()
            raise BillError("Could not record the payment.")

    @classmethod
    def mark_unpaid(cls, user, bill_id):
        b = cls.get_owned(user.id, bill_id)
        if b.status != "paid":
            raise BillError("This bill is not paid.")
        try:
            if b.paid_transaction_id:
                tx = ExpenseTransaction.query.filter_by(id=b.paid_transaction_id, user_id=user.id).first()
                b.paid_transaction_id = None
                if tx:
                    db.session.flush()
                    db.session.delete(tx)
            b.status, b.paid_date = "unpaid", None
            db.session.commit()
        except SQLAlchemyError:
            db.session.rollback()
            raise BillError("Could not undo the payment.")

    @staticmethod
    def for_month(user_id, year, month):
        last = calendar.monthrange(year, month)[1]
        return (Bill.query.filter(Bill.user_id == user_id, Bill.due_date >= date(year, month, 1),
                                  Bill.due_date <= date(year, month, last))
                .order_by(Bill.due_date, Bill.id).all())

    @staticmethod
    def upcoming(user_id, today=None, days=30, limit=None):
        today = today or date.today()
        q = Bill.query.filter(Bill.user_id == user_id, Bill.status == "unpaid",
                              Bill.due_date <= today + timedelta(days=days)).order_by(Bill.due_date, Bill.id)
        return q.limit(limit).all() if limit else q.all()

    @classmethod
    def summary(cls, user_id, today=None):
        today = today or date.today()
        due = cls.upcoming(user_id, today, days=7)
        overdue = [b for b in due if b.due_date < today]
        total = sum((to_decimal(b.amount) for b in due), to_decimal(0))
        return {"count": len(due), "total": total, "overdue": overdue, "next": due[0] if due else None}


def occurrences(frequency, start_date, window_start, window_end, end_date=None):
    out = []
    last_allowed = min(window_end, end_date) if end_date else window_end
    if frequency == "weekly":
        d = start_date
        if d < window_start:
            d += timedelta(days=7 * (-(-(window_start - d).days // 7)))
        while d <= last_allowed:
            out.append(d)
            d += timedelta(days=7)
    else:
        y, m = start_date.year, start_date.month
        while True:
            d = date(y, m, min(start_date.day, calendar.monthrange(y, m)[1]))  # Jan 31 -> Feb 28
            if d > last_allowed:
                break
            if d >= window_start:
                out.append(d)
            y, m = (y + 1, 1) if m == 12 else (y, m + 1)
    return out


class RecurringService:
    @staticmethod
    def get_owned(user_id, rid):
        r = RecurringExpense.query.filter_by(id=rid, user_id=user_id).first()
        if r is None:
            raise LookupError("Recurring expense not found")
        return r

    @classmethod
    def _clean(cls, user, name, amount, frequency, start_date, end_date, category_id, account_id):
        amt = _check_common(user.id, name, amount, category_id, account_id)
        if frequency not in ("weekly", "monthly"):
            raise BillError("Frequency must be weekly or monthly.")
        if not start_date:
            raise BillError("Start date is required.")
        if end_date and end_date < start_date:
            raise BillError("End date must be on or after the start date.")
        return amt

    @classmethod
    def create(cls, user, name, amount, frequency, start_date, end_date=None, category_id=None, account_id=None):
        amt = cls._clean(user, name, amount, frequency, start_date, end_date, category_id, account_id)
        try:
            r = RecurringExpense(user_id=user.id, name=name.strip(), amount=amt, frequency=frequency,
                                 start_date=start_date, end_date=end_date,
                                 category_id=category_id or None, account_id=account_id or None)
            db.session.add(r)
            db.session.commit()
        except SQLAlchemyError:
            db.session.rollback()
            raise BillError("Could not save.")
        cls.generate_bills(user.id)
        return r

    @classmethod
    def update(cls, user, rid, name, amount, frequency, start_date, end_date=None, category_id=None, account_id=None):
        r = cls.get_owned(user.id, rid)
        amt = cls._clean(user, name, amount, frequency, start_date, end_date, category_id, account_id)
        try:
            r.name, r.amount, r.frequency = name.strip(), amt, frequency
            r.start_date, r.end_date = start_date, end_date
            r.category_id, r.account_id = category_id or None, account_id or None
            # future unpaid bills follow the new details; paid history is untouched
            Bill.query.filter(Bill.recurring_id == r.id, Bill.status == "unpaid",
                              Bill.due_date >= date.today()).delete()
            db.session.commit()
        except SQLAlchemyError:
            db.session.rollback()
            raise BillError("Could not update.")
        cls.generate_bills(user.id)
        return r

    @classmethod
    def toggle(cls, user, rid):
        r = cls.get_owned(user.id, rid)
        r.active = not r.active
        if not r.active:
            Bill.query.filter(Bill.recurring_id == r.id, Bill.status == "unpaid",
                              Bill.due_date >= date.today()).delete()
        db.session.commit()
        cls.generate_bills(user.id)

    @classmethod
    def delete(cls, user, rid):
        r = cls.get_owned(user.id, rid)
        Bill.query.filter(Bill.recurring_id == r.id, Bill.status == "unpaid").delete()
        Bill.query.filter(Bill.recurring_id == r.id).update({"recurring_id": None})
        db.session.delete(r)
        db.session.commit()

    @staticmethod
    def generate_bills(user_id, today=None):
        """Create upcoming bills from active schedules. Safe to call repeatedly (no duplicates)."""
        today = today or date.today()
        horizon = today + timedelta(days=60)
        created = 0
        try:
            for r in RecurringExpense.query.filter_by(user_id=user_id, active=True):
                existing = {d for (d,) in db.session.query(Bill.due_date).filter_by(recurring_id=r.id)}
                for d in occurrences(r.frequency, r.start_date, max(r.start_date, today.replace(day=1)),
                                     horizon, r.end_date):
                    if d not in existing:
                        db.session.add(Bill(user_id=user_id, name=r.name, amount=r.amount, due_date=d,
                                            category_id=r.category_id, account_id=r.account_id, recurring_id=r.id))
                        created += 1
            db.session.commit()
        except SQLAlchemyError:
            db.session.rollback()
        return created
