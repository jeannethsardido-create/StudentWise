from datetime import date
from decimal import Decimal
from sqlalchemy import func
from sqlalchemy.exc import SQLAlchemyError
from app.extensions import db
from app.models import SavingsGoal, SavingsEntry
from app.services.transaction_service import TransactionService as TS, TransactionError
from app.utils.money import to_decimal

ZERO = Decimal("0.00")


class SavingsError(ValueError):
    pass


class SavingsService:
    @staticmethod
    def get_owned(user_id, goal_id):
        g = SavingsGoal.query.filter_by(id=goal_id, user_id=user_id).first()
        if g is None:
            raise LookupError("Goal not found")
        return g

    @staticmethod
    def _amount(value):
        try:
            return TS._clean_amount(value)
        except TransactionError as e:
            raise SavingsError(str(e))

    @classmethod
    def create(cls, user, name, target_amount, target_date=None):
        if not (name or "").strip():
            raise SavingsError("Goal name is required.")
        amt = cls._amount(target_amount)
        g = SavingsGoal(user_id=user.id, name=name.strip(), target_amount=amt, target_date=target_date)
        db.session.add(g)
        db.session.commit()
        return g

    @classmethod
    def update(cls, user, goal_id, name, target_amount, target_date=None):
        g = cls.get_owned(user.id, goal_id)
        if not (name or "").strip():
            raise SavingsError("Goal name is required.")
        g.name, g.target_amount, g.target_date = name.strip(), cls._amount(target_amount), target_date
        cls._sync_status(g)
        db.session.commit()
        return g

    @classmethod
    def delete(cls, user, goal_id):
        g = cls.get_owned(user.id, goal_id)
        db.session.delete(g)
        db.session.commit()

    @staticmethod
    def saved(goal_id):
        def total(kind):
            return to_decimal(db.session.query(func.coalesce(func.sum(SavingsEntry.amount), 0))
                              .filter_by(savings_goal_id=goal_id, entry_type=kind).scalar())
        return total("contribution") - total("withdrawal")

    @classmethod
    def _sync_status(cls, g):
        g.status = "completed" if cls.saved(g.id) >= to_decimal(g.target_amount) else "active"

    @classmethod
    def add_entry(cls, user, goal_id, entry_type, amount, entry_date=None, notes=None):
        g = cls.get_owned(user.id, goal_id)
        if entry_type not in ("contribution", "withdrawal"):
            raise SavingsError("Entry must be a contribution or a withdrawal.")
        amt = cls._amount(amount)
        if entry_type == "withdrawal" and amt > cls.saved(g.id):
            raise SavingsError("You can't withdraw more than the amount saved.")
        if entry_type == "contribution" and g.status == "completed":
            raise SavingsError("This goal is already completed.")
        try:
            db.session.add(SavingsEntry(user_id=user.id, savings_goal_id=g.id, entry_type=entry_type,
                                        amount=amt, entry_date=entry_date or date.today(), notes=notes))
            db.session.flush()
            cls._sync_status(g)
            db.session.commit()
        except SQLAlchemyError:
            db.session.rollback()
            raise SavingsError("Could not save the entry.")
        return g

    @classmethod
    def mark_completed(cls, user, goal_id):
        g = cls.get_owned(user.id, goal_id)
        g.status = "completed"
        db.session.commit()

    @classmethod
    def progress(cls, goal, today=None):
        today = today or date.today()
        saved, target = cls.saved(goal.id), to_decimal(goal.target_amount)
        remaining = max(target - saved, ZERO)
        percent = min(Decimal("100"), (saved / target * 100)).quantize(Decimal("0.1")) if target else Decimal("0")
        days_left = (goal.target_date - today).days if goal.target_date else None
        per_day = per_week = None
        if days_left and days_left > 0 and remaining > 0:
            per_day = to_decimal(remaining / days_left)
            per_week = to_decimal(remaining / days_left * 7)
        return {"goal": goal, "saved": saved, "remaining": remaining, "percent": percent,
                "days_left": days_left, "per_day": per_day, "per_week": per_week}

    @classmethod
    def all_progress(cls, user_id, today=None):
        goals = SavingsGoal.query.filter_by(user_id=user_id).order_by(SavingsGoal.status, SavingsGoal.id).all()
        return [cls.progress(g, today) for g in goals]

    @classmethod
    def totals(cls, user_id):
        items = cls.all_progress(user_id)
        saved = sum((i["saved"] for i in items), ZERO)
        target = sum((to_decimal(i["goal"].target_amount) for i in items), ZERO)
        pct = min(Decimal("100"), saved / target * 100).quantize(Decimal("0.1")) if target else Decimal("0.0")
        return {"saved": saved, "target": target, "percent": pct, "count": len(items)}
