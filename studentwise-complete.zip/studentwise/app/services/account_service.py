from sqlalchemy.exc import SQLAlchemyError
from app.extensions import db
from app.models import (Account, Transaction, Bill, RecurringExpense, SavingsEntry, SavingsGoal,
                        ImportBatch, Budget, Category, User, Notification)


class SettingsError(ValueError):
    pass


class AccountService:
    @staticmethod
    def add_account(user, name, account_type, provider=None):
        name = (name or "").strip()
        if not name:
            raise SettingsError("Account name is required.")
        if account_type not in ("cash", "ewallet", "bank"):
            raise SettingsError("Choose a valid account type.")
        if Account.query.filter_by(user_id=user.id, account_name=name).first():
            raise SettingsError("You already have an account with that name.")
        db.session.add(Account(user_id=user.id, account_name=name, account_type=account_type,
                               provider=(provider or None), tracking_method="manual"))
        db.session.commit()

    @staticmethod
    def delete_account(user, account_id):
        acc = Account.query.filter_by(id=account_id, user_id=user.id).first()
        if acc is None:
            raise LookupError("Account not found")
        if Transaction.query.filter_by(account_id=acc.id).count():
            raise SettingsError("This account has records. Delete or move them first.")
        Bill.query.filter_by(account_id=acc.id).update({"account_id": None})
        RecurringExpense.query.filter_by(account_id=acc.id).update({"account_id": None})
        db.session.delete(acc)
        db.session.commit()


class UserService:
    @staticmethod
    def update_name(user, name):
        name = (name or "").strip()
        if not name:
            raise SettingsError("Name is required.")
        user.name = name
        db.session.commit()

    @staticmethod
    def change_password(user, current, new):
        if not user.check_password(current):
            raise SettingsError("Current password is incorrect.")
        if len(new or "") < 8:
            raise SettingsError("New password must be at least 8 characters.")
        user.set_password(new)
        db.session.commit()

    @staticmethod
    def delete_user(user, password):
        if not user.check_password(password):
            raise SettingsError("Password is incorrect.")
        uid = user.id
        try:
            # children first so foreign keys are never violated
            Notification.query.filter_by(user_id=uid).delete()
            Bill.query.filter_by(user_id=uid).delete()
            RecurringExpense.query.filter_by(user_id=uid).delete()
            SavingsEntry.query.filter_by(user_id=uid).delete()
            SavingsGoal.query.filter_by(user_id=uid).delete()
            ImportBatch.query.filter_by(user_id=uid).delete()
            Budget.query.filter_by(user_id=uid).delete()
            Transaction.query.filter_by(user_id=uid).delete()
            Category.query.filter_by(user_id=uid).delete()
            Account.query.filter_by(user_id=uid).delete()
            User.query.filter_by(id=uid).delete()
            db.session.commit()
        except SQLAlchemyError:
            db.session.rollback()
            raise SettingsError("Could not delete the account.")
