from sqlalchemy.exc import SQLAlchemyError
from app.extensions import db
from app.models import User, Account
from app.models.category import seed_default_categories


class AuthService:
    """Business logic for accounts; routes only call these methods."""

    @staticmethod
    def register(name, email, password):
        try:
            user = User(name=name.strip(), email=email.strip().lower())
            user.set_password(password)
            db.session.add(user)
            db.session.flush()
            db.session.add(Account(user_id=user.id, account_name="Cash", account_type="cash"))
            seed_default_categories()
            db.session.commit()
            return user
        except SQLAlchemyError:
            db.session.rollback()
            raise

    @staticmethod
    def authenticate(email, password):
        user = User.query.filter_by(email=email.strip().lower()).first()
        if user and user.check_password(password):
            return user
        return None
