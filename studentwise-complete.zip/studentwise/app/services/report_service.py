import calendar
from datetime import date, timedelta
from decimal import Decimal
from sqlalchemy import func
from app.extensions import db
from app.models import Transaction, Account
from app.services.budget_service import BudgetCalculationService as Calc
from app.utils.dates import day_start, day_end_exclusive
from app.utils.money import to_decimal

ZERO = Decimal("0.00")


def month_range(year, month):
    return date(year, month, 1), date(year, month, calendar.monthrange(year, month)[1])


def last_months(n, today=None):
    today = today or date.today()
    y, m, out = today.year, today.month, []
    for _ in range(n):
        out.append((y, m))
        y, m = (y - 1, 12) if m == 1 else (y, m - 1)
    return list(reversed(out))


class FinancialReportService:
    @staticmethod
    def monthly_history(user_id, n=12, today=None):
        rows = []
        for y, m in last_months(n, today):
            s, e = month_range(y, m)
            t = Calc.totals(user_id, s, e)
            cats = Calc.category_breakdown(user_id, s, e)
            rate = (t["net"] / t["income"] * 100).quantize(Decimal("0.1")) if t["income"] > 0 else None
            rows.append({"label": date(y, m, 1).strftime("%b %Y"), "income": t["income"],
                         "expenses": t["expenses"], "net": t["net"], "savings_rate": rate,
                         "top_category": cats[0][0] if cats else None})
        return rows

    @staticmethod
    def daily_spending(user_id, start, end):
        q = (db.session.query(func.date(Transaction.transaction_date), func.sum(Transaction.amount))
             .filter(Transaction.user_id == user_id, Transaction.transaction_type == "expense",
                     Transaction.status == "completed",
                     Transaction.transaction_date >= day_start(start),
                     Transaction.transaction_date < day_end_exclusive(end))
             .group_by(func.date(Transaction.transaction_date)).all())
        by_day = {str(d): to_decimal(a) for d, a in q}
        days, d = [], start
        while d <= end:
            days.append((d, by_day.get(d.isoformat(), ZERO)))
            d += timedelta(days=1)
        return days

    @staticmethod
    def account_summary(user_id, start, end):
        res = []
        for acc in Account.query.filter_by(user_id=user_id).order_by(Account.account_name):
            def s(kind):
                return to_decimal(db.session.query(func.coalesce(func.sum(Transaction.amount), 0)).filter(
                    Transaction.user_id == user_id, Transaction.account_id == acc.id,
                    Transaction.transaction_type == kind, Transaction.status == "completed",
                    Transaction.transaction_date >= day_start(start),
                    Transaction.transaction_date < day_end_exclusive(end)).scalar())
            i, x = s("income"), s("expense")
            res.append({"name": acc.account_name, "type": acc.account_type, "income": i, "expenses": x, "net": i - x})
        return res
