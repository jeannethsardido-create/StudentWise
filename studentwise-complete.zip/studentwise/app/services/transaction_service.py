from datetime import datetime, date
from decimal import Decimal, InvalidOperation
from sqlalchemy import or_
from sqlalchemy.exc import SQLAlchemyError
from app.extensions import db
from app.models import Transaction, IncomeTransaction, ExpenseTransaction, Account, Category, Bill
from app.utils.money import to_decimal
from app.utils.dates import day_start, day_end_exclusive

TYPE_CLASSES = {"income": IncomeTransaction, "expense": ExpenseTransaction}
VALID_STATUS = {"completed", "pending", "failed", "reversed"}


class TransactionError(ValueError):
    """User-facing validation problem."""


class TransactionService:
    """All transaction rules live here; routes never touch the DB directly."""

    # ---------- ownership helpers (server-side privacy enforcement) ----------
    @staticmethod
    def get_owned(user_id, tx_id):
        tx = Transaction.query.filter_by(id=tx_id, user_id=user_id).first()
        if tx is None:
            raise LookupError("Transaction not found")
        return tx

    @staticmethod
    def _owned_account(user_id, account_id):
        acc = Account.query.filter_by(id=account_id, user_id=user_id).first()
        if acc is None:
            raise TransactionError("Choose one of your own accounts.")
        return acc

    @staticmethod
    def _visible_category(user_id, category_id, tx_type):
        if not category_id:
            return None
        cat = Category.query.filter(
            Category.id == category_id,
            or_(Category.user_id == user_id, Category.user_id.is_(None)),
        ).first()
        if cat is None:
            raise TransactionError("Choose a valid category.")
        if cat.category_type != tx_type:
            raise TransactionError("That category is for %s records." % cat.category_type)
        return cat

    @staticmethod
    def _clean_amount(value):
        try:
            amount = to_decimal(value)
        except (InvalidOperation, ValueError, TypeError):
            raise TransactionError("Amount must be a number.")
        if amount <= Decimal("0"):
            raise TransactionError("Amount must be greater than zero.")
        return amount

    @staticmethod
    def _clean_date(value):
        if isinstance(value, datetime):
            return value
        if isinstance(value, date):
            return day_start(value)
        raise TransactionError("Enter a valid date.")

    # ---------- CRUD ----------
    @classmethod
    def create(cls, user, tx_type, description, amount, account_id,
               category_id=None, tx_date=None, status="completed", notes=None, source="manual"):
        if tx_type not in TYPE_CLASSES:
            raise TransactionError("Type must be income or expense.")
        if not (description or "").strip():
            raise TransactionError("Description is required.")
        if status not in VALID_STATUS:
            raise TransactionError("Invalid status.")
        amount = cls._clean_amount(amount)
        acc = cls._owned_account(user.id, account_id)
        cat = cls._visible_category(user.id, category_id, tx_type)
        try:
            tx = TYPE_CLASSES[tx_type](
                user_id=user.id, account_id=acc.id, description=description.strip(),
                amount=amount, category_id=cat.id if cat else None,
                transaction_date=cls._clean_date(tx_date or date.today()),
                status=status, notes=notes, source=source,
            )
            db.session.add(tx)
            db.session.commit()
            return tx
        except SQLAlchemyError:
            db.session.rollback()
            raise TransactionError("Could not save the record. Please try again.")

    @classmethod
    def update(cls, user, tx_id, description, amount, account_id,
               category_id=None, tx_date=None, status="completed", notes=None):
        tx = cls.get_owned(user.id, tx_id)
        if not (description or "").strip():
            raise TransactionError("Description is required.")
        if status not in VALID_STATUS:
            raise TransactionError("Invalid status.")
        amount = cls._clean_amount(amount)
        acc = cls._owned_account(user.id, account_id)
        cat = cls._visible_category(user.id, category_id, tx.transaction_type)
        try:
            tx.description = description.strip()
            tx.amount = amount
            tx.account_id = acc.id
            tx.category_id = cat.id if cat else None
            tx.transaction_date = cls._clean_date(tx_date or tx.transaction_date)
            tx.status = status
            tx.notes = notes
            db.session.commit()
            return tx
        except SQLAlchemyError:
            db.session.rollback()
            raise TransactionError("Could not update the record. Please try again.")

    @classmethod
    def delete(cls, user, tx_id):
        tx = cls.get_owned(user.id, tx_id)
        try:
            # a bill paid by this record goes back to unpaid instead of pointing at nothing
            for bill in Bill.query.filter_by(paid_transaction_id=tx.id, user_id=user.id):
                bill.status, bill.paid_date, bill.paid_transaction_id = "unpaid", None, None
            db.session.delete(tx)
            db.session.commit()
        except SQLAlchemyError:
            db.session.rollback()
            raise TransactionError("Could not delete the record.")

    @staticmethod
    def search(user_id, q=None, tx_type=None, category_id=None, start=None, end=None,
               sort="date_desc", limit=200):
        query = Transaction.query.filter(Transaction.user_id == user_id)
        if q:
            like = "%" + q.strip() + "%"
            query = query.filter(or_(Transaction.description.ilike(like), Transaction.notes.ilike(like)))
        if tx_type in TYPE_CLASSES:
            query = query.filter(Transaction.transaction_type == tx_type)
        if category_id:
            query = query.filter(Transaction.category_id == category_id)
        if start:
            query = query.filter(Transaction.transaction_date >= day_start(start))
        if end:
            query = query.filter(Transaction.transaction_date < day_end_exclusive(end))
        order = {
            "date_asc": Transaction.transaction_date.asc(),
            "amount_desc": Transaction.amount.desc(),
            "amount_asc": Transaction.amount.asc(),
        }.get(sort, Transaction.transaction_date.desc())
        return query.order_by(order, Transaction.id.desc()).limit(limit).all()
