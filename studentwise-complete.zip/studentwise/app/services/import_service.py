import csv
import hashlib
import io
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime, date
from decimal import Decimal, InvalidOperation
from sqlalchemy import or_
from sqlalchemy.exc import SQLAlchemyError
from app.extensions import db
from app.models import ImportBatch, Account, Category, Transaction, IncomeTransaction, ExpenseTransaction
from app.utils.dates import day_start
from app.utils.money import to_decimal

MAX_ROWS = 2000
DATE_FORMATS = ("%Y-%m-%d", "%m/%d/%Y", "%b %d, %Y", "%d %b %Y")
INCOME_WORDS = {"income", "credit", "in", "cash in", "received"}
EXPENSE_WORDS = {"expense", "debit", "out", "cash out", "payment", "sent"}


class ImportError_(ValueError):
    """User-facing import problem."""


@dataclass
class ParsedRow:
    line: int
    date: date = None
    description: str = ""
    amount: Decimal = None
    tx_type: str = ""
    external_id: str = ""
    category_id: int = None
    error: str = ""
    status: str = "ok"   # ok / duplicate / error


class AbstractTransactionImporter(ABC):
    """Every source (CSV today, an official wallet API later) turns raw data into ParsedRow objects."""
    source = ""

    @abstractmethod
    def parse(self, raw: str, category_lookup: dict) -> list:
        ...


class CSVTransactionImporter(AbstractTransactionImporter):
    source = "csv"
    REQUIRED = ("date", "description", "amount")

    @staticmethod
    def _parse_date(text):
        for fmt in DATE_FORMATS:
            try:
                return datetime.strptime(text.strip(), fmt).date()
            except ValueError:
                continue
        return None

    @staticmethod
    def _parse_amount(text):
        cleaned = text.replace("\u20b1", "").replace("PHP", "").replace(",", "").replace(" ", "").strip()
        neg = cleaned.startswith("(") and cleaned.endswith(")")
        cleaned = cleaned.strip("()")
        try:
            val = Decimal(cleaned)
        except InvalidOperation:
            return None
        return -val if neg else val

    def parse(self, raw, category_lookup):
        reader = csv.DictReader(io.StringIO(raw))
        if not reader.fieldnames:
            raise ImportError_("The file is empty.")
        reader.fieldnames = [(h or "").strip().lower() for h in reader.fieldnames]
        missing = [c for c in self.REQUIRED if c not in reader.fieldnames]
        if missing:
            raise ImportError_("Missing column(s): %s. Expected: date, description, amount "
                               "(optional: type, reference, category)." % ", ".join(missing))
        rows, seen_fp = [], {}
        for i, rec in enumerate(reader, start=2):
            if len(rows) >= MAX_ROWS:
                raise ImportError_("Too many rows (limit %d)." % MAX_ROWS)
            row = ParsedRow(line=i)
            rows.append(row)
            get = lambda k: (rec.get(k) or "").strip()
            row.description = get("description")[:255]
            row.date = self._parse_date(get("date"))
            amount = self._parse_amount(get("amount"))
            if not row.description:
                row.error = "Description is empty."
            elif row.date is None:
                row.error = "Date not recognised (use YYYY-MM-DD)."
            elif amount is None or amount == 0:
                row.error = "Amount is not a valid non-zero number."
            if row.error:
                row.status = "error"
                continue
            kind = get("type").lower()
            if kind in INCOME_WORDS:
                row.tx_type = "income"
            elif kind in EXPENSE_WORDS:
                row.tx_type = "expense"
            elif kind:
                row.status, row.error = "error", "Type '%s' is not recognised." % kind
                continue
            else:
                row.tx_type = "income" if amount > 0 else "expense"
            row.amount = to_decimal(abs(amount))
            row.category_id = category_lookup.get((get("category").lower(), row.tx_type))
            ref = get("reference")
            if ref:
                row.external_id = "ref:" + ref[:90]
            else:  # stable fingerprint; nth identical row in a file gets its own id
                fp = "%s|%s|%s|%s" % (row.date, row.amount, row.description.lower(), row.tx_type)
                seen_fp[fp] = seen_fp.get(fp, 0) + 1
                row.external_id = "fp:%s#%d" % (hashlib.sha1(fp.encode()).hexdigest()[:24], seen_fp[fp])
        return rows


class ImportService:
    importers = {"csv": CSVTransactionImporter}

    @staticmethod
    def get_owned(user_id, batch_id):
        b = ImportBatch.query.filter_by(id=batch_id, user_id=user_id).first()
        if b is None:
            raise LookupError("Import not found")
        return b

    @staticmethod
    def _category_lookup(user_id):
        cats = Category.query.filter(or_(Category.user_id == user_id, Category.user_id.is_(None))).all()
        return {(c.name.lower(), c.category_type): c.id for c in cats}

    @classmethod
    def _analyse(cls, batch):
        rows = cls.importers[batch.source]().parse(batch.raw_csv, cls._category_lookup(batch.user_id))
        existing = {e for (e,) in db.session.query(Transaction.external_transaction_id).filter(
            Transaction.account_id == batch.account_id, Transaction.external_transaction_id.isnot(None))}
        seen = set()
        for r in rows:
            if r.status == "ok":
                if r.external_id in existing or r.external_id in seen:
                    r.status = "duplicate"
                seen.add(r.external_id)
        return rows

    @classmethod
    def start_preview(cls, user, account_id, filename, raw_bytes):
        acc = Account.query.filter_by(id=account_id, user_id=user.id).first()
        if acc is None:
            raise ImportError_("Choose one of your own accounts.")
        try:
            raw = raw_bytes.decode("utf-8-sig")
        except UnicodeDecodeError:
            raise ImportError_("The file must be a UTF-8 CSV.")
        batch = ImportBatch(user_id=user.id, account_id=acc.id, source="csv", filename=(filename or "")[:255],
                            raw_csv=raw, import_status="preview")
        cls._analyse(batch)  # raises ImportError_ for a bad file before anything is saved
        ImportBatch.query.filter_by(user_id=user.id, import_status="preview").delete()
        db.session.add(batch)
        db.session.commit()
        return batch

    @classmethod
    def preview(cls, user, batch_id):
        batch = cls.get_owned(user.id, batch_id)
        rows = cls._analyse(batch)
        counts = {k: sum(1 for r in rows if r.status == k) for k in ("ok", "duplicate", "error")}
        return batch, rows, counts

    @classmethod
    def confirm(cls, user, batch_id):
        batch, rows, counts = cls.preview(user, batch_id)
        if batch.import_status != "preview":
            raise ImportError_("This import was already processed.")
        try:
            for r in rows:
                if r.status != "ok":
                    continue
                cls_ = IncomeTransaction if r.tx_type == "income" else ExpenseTransaction
                db.session.add(cls_(user_id=user.id, account_id=batch.account_id, description=r.description,
                                    amount=r.amount, category_id=r.category_id,
                                    transaction_date=day_start(r.date), status="completed", source="csv_import",
                                    external_transaction_id=r.external_id,
                                    notes="Imported from %s" % (batch.filename or "CSV")))
            batch.import_status = "completed"
            batch.records_processed = len(rows)
            batch.records_imported = counts["ok"]
            batch.records_skipped = counts["duplicate"] + counts["error"]
            batch.imported_at = datetime.now()
            batch.raw_csv = None
            db.session.commit()  # all valid rows or none: one bad write never leaves half an import
        except SQLAlchemyError:
            db.session.rollback()
            raise ImportError_("The import failed and nothing was saved. Please try again.")
        return batch

    @classmethod
    def cancel(cls, user, batch_id):
        batch = cls.get_owned(user.id, batch_id)
        if batch.import_status == "preview":
            db.session.delete(batch)
            db.session.commit()
