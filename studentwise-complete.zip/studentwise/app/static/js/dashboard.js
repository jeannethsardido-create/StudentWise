// The backend calculates every number; this only displays /api/dashboard's answer.
const periodSelect = document.getElementById("period");
periodSelect.addEventListener("change", async (e) => {
  const range = document.getElementById("range");
  if (e.target.value === "custom") { range.style.display = "flex"; return; }
  range.style.display = "none";
  try {
    const res = await fetch("/api/dashboard?period=" + encodeURIComponent(e.target.value));
    if (!res.ok) throw new Error("Request failed");
    const data = await res.json();
    document.querySelectorAll("[data-field]").forEach((el) => {
      if (el.dataset.field in data) el.textContent = data[el.dataset.field];
    });
    const f = document.getElementById("period-form");
    f.elements["start"].value = data.start;
    f.elements["end"].value = data.end;
  } catch (err) {
    e.target.form.submit();   // fall back to a normal reload
  }
});
