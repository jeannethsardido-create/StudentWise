from decimal import Decimal, ROUND_HALF_UP

CENT = Decimal("0.01")


def to_decimal(value) -> Decimal:
    """Convert any value to a 2-place Decimal (never uses float arithmetic)."""
    return Decimal(str(value)).quantize(CENT, rounding=ROUND_HALF_UP)


def peso(value) -> str:
    return "\u20b1{:,.2f}".format(Decimal(str(value or 0)))
