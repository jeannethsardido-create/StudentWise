from datetime import date, datetime, time, timedelta


def parse_date(text):
    try:
        return datetime.strptime(text, "%Y-%m-%d").date() if text else None
    except ValueError:
        return None


def day_start(d: date) -> datetime:
    return datetime.combine(d, time.min)


def day_end_exclusive(d: date) -> datetime:
    return datetime.combine(d + timedelta(days=1), time.min)


def resolve_period(period, start_text=None, end_text=None, today=None):
    """Return (period_name, start_date, end_date) inclusive. Falls back to 'month'."""
    today = today or date.today()
    if period == "today":
        return "today", today, today
    if period == "week":
        monday = today - timedelta(days=today.weekday())
        return "week", monday, monday + timedelta(days=6)
    if period == "custom":
        s, e = parse_date(start_text), parse_date(end_text)
        if s and e and s <= e:
            return "custom", s, e
    first = today.replace(day=1)
    nxt = (first + timedelta(days=32)).replace(day=1)
    return "month", first, nxt - timedelta(days=1)
