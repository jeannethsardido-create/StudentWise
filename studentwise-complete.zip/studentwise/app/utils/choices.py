from sqlalchemy import or_
from app.models import Account, Category


def account_choices(user_id, allow_none=False):
    items = [(a.id, a.account_name) for a in Account.query.filter_by(user_id=user_id).order_by(Account.account_name)]
    return ([(0, "-- default account --")] + items) if allow_none else items


def category_choices(user_id, kind="expense"):
    cats = Category.query.filter(Category.category_type == kind,
                                 or_(Category.user_id == user_id, Category.user_id.is_(None))) \
        .order_by(Category.name).all()
    return [(0, "-- none --")] + [(c.id, c.name) for c in cats]
