from app.extensions import db

DEFAULT_EXPENSE_CATEGORIES = [
    "Food and Drinks", "Transportation", "School Supplies", "Tuition and School Fees",
    "Load and Internet", "Personal Needs", "Entertainment", "Shopping", "Bills",
    "Health and Emergency", "Savings Contribution", "Other",
]
DEFAULT_INCOME_CATEGORIES = ["Allowance", "Salary", "Freelance", "Gift", "Other Income"]


class Category(db.Model):
    __tablename__ = "categories"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True, index=True)  # NULL = global default
    name = db.Column(db.String(80), nullable=False)
    category_type = db.Column(db.String(10), nullable=False)  # income / expense
    is_default = db.Column(db.Boolean, nullable=False, default=False)

    user = db.relationship("User", back_populates="categories")

    __table_args__ = (db.UniqueConstraint("user_id", "name", "category_type", name="uq_category"),)


def seed_default_categories():
    """Insert the predefined global categories once (safe to call repeatedly)."""
    existing = {(c.name, c.category_type) for c in Category.query.filter_by(user_id=None)}
    for name in DEFAULT_EXPENSE_CATEGORIES:
        if (name, "expense") not in existing:
            db.session.add(Category(name=name, category_type="expense", is_default=True))
    for name in DEFAULT_INCOME_CATEGORIES:
        if (name, "income") not in existing:
            db.session.add(Category(name=name, category_type="income", is_default=True))
    db.session.flush()
