from app.extensions import db
from app.models.user import utcnow


class ImportBatch(db.Model):
    __tablename__ = "import_batches"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    account_id = db.Column(db.Integer, db.ForeignKey("accounts.id"), nullable=False)
    source = db.Column(db.String(20), nullable=False, default="csv")
    filename = db.Column(db.String(255))
    imported_at = db.Column(db.DateTime, default=utcnow)
    import_status = db.Column(db.String(12), nullable=False, default="preview")  # preview / completed / failed
    records_processed = db.Column(db.Integer, default=0)
    records_imported = db.Column(db.Integer, default=0)
    records_skipped = db.Column(db.Integer, default=0)
    raw_csv = db.Column(db.Text)

    account = db.relationship("Account")
