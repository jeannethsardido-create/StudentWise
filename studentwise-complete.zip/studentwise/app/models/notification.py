from app.extensions import db
from app.models.user import utcnow


class Notification(db.Model):
    __tablename__ = "notifications"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    title = db.Column(db.String(150), nullable=False)
    message = db.Column(db.String(500), nullable=False)
    notification_type = db.Column(db.String(30), nullable=False)  # bill_due / bill_overdue / budget_warning / budget_exceeded / test
    related_record_type = db.Column(db.String(30))
    related_record_id = db.Column(db.Integer)
    is_read = db.Column(db.Boolean, nullable=False, default=False)
    created_at = db.Column(db.DateTime, default=utcnow, index=True)
    dedupe_key = db.Column(db.String(120), nullable=False)
    email_status = db.Column(db.String(20))   # sent / failed / not_configured / off
    sms_status = db.Column(db.String(20))

    # one alert per event per user: refreshing a page can never create a duplicate
    __table_args__ = (db.UniqueConstraint("user_id", "dedupe_key", name="uq_notification_dedupe"),)
