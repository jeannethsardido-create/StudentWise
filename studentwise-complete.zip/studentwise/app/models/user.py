from datetime import datetime, timezone
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from app.extensions import db, login_manager


def utcnow():
    return datetime.now(timezone.utc)


class User(UserMixin, db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(255), unique=True, nullable=False, index=True)
    _password_hash = db.Column("password_hash", db.String(255), nullable=False)
    currency = db.Column(db.String(3), nullable=False, default="PHP")
    timezone = db.Column(db.String(50), nullable=False, default="Asia/Manila")
    phone = db.Column(db.String(20))                      # mobile number for optional SMS alerts
    notify_email = db.Column(db.Boolean, nullable=False, default=True, server_default=db.true())
    notify_sms = db.Column(db.Boolean, nullable=False, default=False, server_default=db.false())
    created_at = db.Column(db.DateTime, default=utcnow)
    updated_at = db.Column(db.DateTime, default=utcnow, onupdate=utcnow)

    accounts = db.relationship("Account", back_populates="user", cascade="all, delete-orphan")
    transactions = db.relationship("Transaction", back_populates="user", cascade="all, delete-orphan")
    categories = db.relationship("Category", back_populates="user", cascade="all, delete-orphan")

    # Encapsulation: the hash is private; callers use these methods only.
    def set_password(self, raw_password):
        self._password_hash = generate_password_hash(raw_password)

    def check_password(self, raw_password):
        return check_password_hash(self._password_hash, raw_password)

    @property
    def password_hash(self):
        return self._password_hash


@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))
