from app.extensions import db
from app.models.user import utcnow


class RecurringExpense(db.Model):
    __tablename__ = "recurring_expenses"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    name = db.Column(db.String(100), nullable=False)
    amount = db.Column(db.Numeric(12, 2), nullable=False)
    category_id = db.Column(db.Integer, db.ForeignKey("categories.id"))
    account_id = db.Column(db.Integer, db.ForeignKey("accounts.id"))
    frequency = db.Column(db.String(10), nullable=False, default="monthly")  # weekly / monthly
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date)
    active = db.Column(db.Boolean, nullable=False, default=True)
    created_at = db.Column(db.DateTime, default=utcnow)

    category = db.relationship("Category")
    account = db.relationship("Account")
    __table_args__ = (db.CheckConstraint("amount > 0", name="ck_recurring_amount_positive"),)


class Bill(db.Model):
    """A planned payment. It is NOT an expense until it is marked paid."""
    __tablename__ = "bills"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    name = db.Column(db.String(100), nullable=False)
    amount = db.Column(db.Numeric(12, 2), nullable=False)
    due_date = db.Column(db.Date, nullable=False, index=True)
    category_id = db.Column(db.Integer, db.ForeignKey("categories.id"))
    account_id = db.Column(db.Integer, db.ForeignKey("accounts.id"))
    status = db.Column(db.String(10), nullable=False, default="unpaid")  # unpaid / paid
    paid_date = db.Column(db.Date)
    paid_transaction_id = db.Column(db.Integer, db.ForeignKey("transactions.id"))
    recurring_id = db.Column(db.Integer, db.ForeignKey("recurring_expenses.id"))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=utcnow)

    category = db.relationship("Category")
    account = db.relationship("Account")
    recurring = db.relationship("RecurringExpense")
    __table_args__ = (
        db.CheckConstraint("amount > 0", name="ck_bill_amount_positive"),
        db.UniqueConstraint("recurring_id", "due_date", name="uq_recurring_due"),
    )
