from app.extensions import db
from app.models.user import utcnow


class Budget(db.Model):
    __tablename__ = "budgets"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    name = db.Column(db.String(100), nullable=False)
    category_id = db.Column(db.Integer, db.ForeignKey("categories.id"))  # NULL = overall budget
    budget_amount = db.Column(db.Numeric(12, 2), nullable=False)
    period_type = db.Column(db.String(20), nullable=False, default="monthly")
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date, nullable=False)
    warning_threshold = db.Column(db.Integer, nullable=False, default=75)
    created_at = db.Column(db.DateTime, default=utcnow)

    user = db.relationship("User", backref=db.backref("budgets", cascade="all, delete-orphan"))
    category = db.relationship("Category")

    __table_args__ = (
        db.CheckConstraint("budget_amount >= 0", name="ck_budget_nonnegative"),
        db.CheckConstraint("warning_threshold BETWEEN 1 AND 100", name="ck_threshold_range"),
    )
