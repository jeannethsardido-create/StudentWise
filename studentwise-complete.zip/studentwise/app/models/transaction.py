from decimal import Decimal
from app.extensions import db
from app.models.user import utcnow


class Transaction(db.Model):
    """Base class (single-table inheritance). Subclasses define how a record
    affects an account balance -> polymorphism via signed_amount()."""
    __tablename__ = "transactions"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    account_id = db.Column(db.Integer, db.ForeignKey("accounts.id"), nullable=False, index=True)
    transaction_type = db.Column(db.String(20), nullable=False)   # income / expense / transfer
    description = db.Column(db.String(255), nullable=False)
    amount = db.Column(db.Numeric(12, 2), nullable=False)
    category_id = db.Column(db.Integer, db.ForeignKey("categories.id"))
    transaction_date = db.Column(db.DateTime, nullable=False, default=utcnow, index=True)
    status = db.Column(db.String(20), nullable=False, default="completed")
    source = db.Column(db.String(20), nullable=False, default="manual")
    external_transaction_id = db.Column(db.String(100))
    notes = db.Column(db.Text)
    transfer_peer_id = db.Column(db.Integer, db.ForeignKey("transactions.id"))
    direction = db.Column(db.String(3))  # used by transfers only: 'in' / 'out'
    created_at = db.Column(db.DateTime, default=utcnow)
    updated_at = db.Column(db.DateTime, default=utcnow, onupdate=utcnow)

    user = db.relationship("User", back_populates="transactions")
    account = db.relationship("Account", back_populates="transactions", foreign_keys=[account_id])
    category = db.relationship("Category")

    __mapper_args__ = {"polymorphic_on": transaction_type, "polymorphic_identity": "base"}
    __table_args__ = (
        db.CheckConstraint("amount > 0", name="ck_amount_positive"),
        db.UniqueConstraint("account_id", "external_transaction_id", name="uq_account_external_id"),
    )

    def signed_amount(self) -> Decimal:
        raise NotImplementedError

    def counts_as_completed(self) -> bool:
        return self.status == "completed"


class IncomeTransaction(Transaction):
    __mapper_args__ = {"polymorphic_identity": "income"}

    def signed_amount(self) -> Decimal:
        return Decimal(self.amount)


class ExpenseTransaction(Transaction):
    __mapper_args__ = {"polymorphic_identity": "expense"}

    def signed_amount(self) -> Decimal:
        return -Decimal(self.amount)


class TransferTransaction(Transaction):
    """One leg of a transfer; excluded from income/expense totals."""
    __mapper_args__ = {"polymorphic_identity": "transfer"}

    def signed_amount(self) -> Decimal:
        return Decimal(self.amount) if self.direction == "in" else -Decimal(self.amount)
