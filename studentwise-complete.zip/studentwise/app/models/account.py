from app.extensions import db
from app.models.user import utcnow


class Account(db.Model):
    __tablename__ = "accounts"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    account_name = db.Column(db.String(100), nullable=False)
    account_type = db.Column(db.String(30), nullable=False)       # cash, ewallet, bank
    provider = db.Column(db.String(50))                           # GCash, Maya, ...
    tracking_method = db.Column(db.String(30), nullable=False, default="manual")
    connection_status = db.Column(db.String(30), nullable=False, default="not_connected")
    currency = db.Column(db.String(3), nullable=False, default="PHP")
    created_at = db.Column(db.DateTime, default=utcnow)

    user = db.relationship("User", back_populates="accounts")
    transactions = db.relationship(
        "Transaction", back_populates="account",
        foreign_keys="Transaction.account_id", cascade="all, delete-orphan",
    )

    __table_args__ = (db.UniqueConstraint("user_id", "account_name", name="uq_user_account_name"),)
