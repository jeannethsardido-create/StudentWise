from app.extensions import db
from app.models.user import utcnow


class SavingsGoal(db.Model):
    __tablename__ = "savings_goals"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    name = db.Column(db.String(100), nullable=False)
    target_amount = db.Column(db.Numeric(12, 2), nullable=False)
    target_date = db.Column(db.Date)
    status = db.Column(db.String(12), nullable=False, default="active")  # active / completed
    created_at = db.Column(db.DateTime, default=utcnow)

    entries = db.relationship("SavingsEntry", back_populates="goal", cascade="all, delete-orphan",
                              order_by="SavingsEntry.entry_date.desc()")
    __table_args__ = (db.CheckConstraint("target_amount > 0", name="ck_goal_target_positive"),)


class SavingsEntry(db.Model):
    """Money RESERVED for a goal. It is not income and not spending, so it never
    changes the available balance or expense totals."""
    __tablename__ = "savings_entries"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    savings_goal_id = db.Column(db.Integer, db.ForeignKey("savings_goals.id"), nullable=False, index=True)
    entry_type = db.Column(db.String(12), nullable=False)  # contribution / withdrawal
    amount = db.Column(db.Numeric(12, 2), nullable=False)
    entry_date = db.Column(db.Date, nullable=False)
    notes = db.Column(db.String(255))

    goal = db.relationship("SavingsGoal", back_populates="entries")
    __table_args__ = (db.CheckConstraint("amount > 0", name="ck_entry_amount_positive"),)
