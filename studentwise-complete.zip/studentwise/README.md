# StudentWise (Stage 2: Core Finance)

## Windows setup
```
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env      (then edit SECRET_KEY)
flask --app run.py db init
flask --app run.py db migrate -m "initial"
flask --app run.py db upgrade
python run.py
```
Open http://127.0.0.1:5000 and register the first user.

## Tests
```
pytest -v
```

## Quick start (Windows)
1. Double-click `setup.bat` (first time only).
2. Double-click `start.bat`, then open http://127.0.0.1:5000

## Features
Dashboard, Income Sources, Expense Log, Categories & Budgets (with pace warnings), Bill Calendar,
Recurring Expenses, Savings Goals, Reports (charts + CSV export), Monthly History,
Import Statement (CSV with preview and duplicate detection), Settings & Data (accounts, password,
CSV export, JSON backup, delete account).

## Updating an existing install
Copy the new files over your folder, then run `start.bat`. It upgrades the database
automatically and keeps your records.

## E-wallets
GCash and Maya have no public personal-transaction API, so StudentWise never claims a live
connection. Use a manual account or import a CSV statement (sample: Import Statement page).

## Email and text alerts (optional)
StudentWise always shows alerts in the Notifications page. To also get them by email or SMS,
add your own account details to `.env` (never share this file):

**Email (example: Gmail).** Turn on 2-Step Verification in your Google account, create an
"App password", then set:
```
MAIL_SERVER=smtp.gmail.com
MAIL_PORT=587
MAIL_USERNAME=youraddress@gmail.com
MAIL_PASSWORD=your-16-letter-app-password
MAIL_FROM=youraddress@gmail.com
```
**Text messages.** Uses the paid Semaphore service (Philippines): create an account, then set
`SEMAPHORE_API_KEY=...` (optionally `SEMAPHORE_SENDER_NAME`). Each text is charged by Semaphore.

Then restart the app, open Settings & Data > Alerts, enter your mobile number, tick the boxes,
and press "Send a test alert". Alerts are created when you open the dashboard or Notifications page.
To get them even when the site is closed, schedule this command daily (Windows Task Scheduler):
```
flask --app run.py send-reminders
```
