from app.models import User


def register(client, email="a@b.com", pw="password123"):
    return client.post("/auth/register", data={"name": "Ana", "email": email, "password": pw, "confirm": pw})


def test_register_success_and_hash(client, app):
    r = register(client)
    assert r.status_code == 302
    user = User.query.filter_by(email="a@b.com").first()
    assert user and user.password_hash != "password123" and user.check_password("password123")


def test_duplicate_email_rejected(client):
    register(client)
    r = register(client)
    assert b"already registered" in r.data


def test_login_logout_and_protection(client):
    assert client.get("/dashboard").status_code == 302  # redirected to login
    register(client)
    r = client.post("/auth/login", data={"email": "a@b.com", "password": "password123"})
    assert r.status_code == 302
    assert client.get("/dashboard").status_code == 200
    client.post("/auth/logout")
    assert client.get("/dashboard").status_code == 302


def test_bad_login(client):
    register(client)
    r = client.post("/auth/login", data={"email": "a@b.com", "password": "wrong"})
    assert b"Invalid email or password" in r.data
