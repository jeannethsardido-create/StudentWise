from datetime import date
from decimal import Decimal
import pytest
from app.models import Budget
from app.services.transaction_service import TransactionService as TS, TransactionError
from app.services.budget_service import BudgetCalculationService as Calc, BudgetService, BudgetError
from tests.helpers import make_user, cash, cat, login

TODAY = date.today()
M_START = TODAY.replace(day=1)


def add(u, kind, amount, desc="x", category=None, status="completed"):
    return TS.create(u, kind, desc, amount, cash(u).id, cat(category, kind).id if category else None,
                     TODAY, status)


def test_spec_example_balance(app):
    u = make_user()
    add(u, "income", "2000", "Allowance", "Allowance")
    add(u, "expense", "300", "Food", "Food and Drinks")
    add(u, "expense", "100", "Fare", "Transportation")
    assert Calc.available_balance(u.id) == Decimal("1600.00")
    t = Calc.totals(u.id, M_START, TODAY)
    assert t["income"] == Decimal("2000.00") and t["expenses"] == Decimal("400.00")


@pytest.mark.parametrize("bad", ["0", "-5", "abc"])
def test_invalid_amounts_rejected(app, bad):
    u = make_user()
    with pytest.raises(TransactionError):
        add(u, "expense", bad)


def test_edit_and_delete_recalculate(app):
    u = make_user()
    tx = add(u, "expense", "120", "Lunch", "Food and Drinks")
    TS.update(u, tx.id, "Lunch", "200", cash(u).id, cat("Food and Drinks").id, TODAY)
    assert Calc.totals(u.id, M_START, TODAY)["expenses"] == Decimal("200.00")
    TS.delete(u, tx.id)
    assert Calc.totals(u.id, M_START, TODAY)["expenses"] == Decimal("0.00")


def test_pending_and_reversed_not_counted(app):
    u = make_user()
    add(u, "expense", "50", status="pending")
    add(u, "expense", "70", status="reversed")
    assert Calc.available_balance(u.id) == Decimal("0.00")


def test_budget_remaining_percent_and_thresholds(app):
    u = make_user()
    b = BudgetService.create(u, "Food", "1500", "monthly", M_START, TODAY.replace(day=28), 75,
                             cat("Food and Drinks").id)
    add(u, "expense", "120", "Lunch", "Food and Drinks")
    add(u, "expense", "999", "Other", "Transportation")      # different category: not counted
    s = Calc.budget_status(b)
    assert s["spent"] == Decimal("120.00") and s["remaining"] == Decimal("1380.00") and s["level"] == "ok"
    add(u, "expense", "1100", "Feast", "Food and Drinks")
    assert Calc.budget_status(b)["level"] == "warning"
    add(u, "expense", "500", "More", "Food and Drinks")
    assert Calc.budget_status(b)["level"] == "exceeded"


def test_zero_budget_is_safe(app):
    u = make_user()
    b = BudgetService.create(u, "Zero", "0", "custom", M_START, TODAY, 50)
    assert Calc.budget_status(b)["percent"] == Decimal("0.0")
    add(u, "expense", "10")
    assert Calc.budget_status(b)["percent"] == Decimal("100.0")


def test_budget_date_validation(app):
    u = make_user()
    with pytest.raises(BudgetError):
        BudgetService.create(u, "Bad", "100", "custom", TODAY, M_START, 75)


def test_cannot_use_other_users_account(app):
    a, b = make_user("a@b.com"), make_user("b@b.com", "Ben")
    with pytest.raises(TransactionError):
        TS.create(b, "expense", "x", "10", cash(a).id)


def test_other_user_cannot_edit_or_delete(app, client):
    a, b = make_user("a@b.com"), make_user("b@b.com", "Ben")
    tx = add(a, "expense", "10")
    login(client, "b@b.com")
    assert client.get("/transactions/%d/edit" % tx.id).status_code == 404
    assert client.post("/transactions/%d/delete" % tx.id).status_code == 404
    with pytest.raises(LookupError):
        TS.get_owned(b.id, tx.id)


def test_routes_create_and_dashboard_api(app, client):
    u = make_user()
    login(client)
    r = client.post("/transactions/new", data={
        "transaction_type": "income", "description": "Allowance", "amount": "2000",
        "account_id": cash(u).id, "category_id": 0, "transaction_date": TODAY.isoformat(),
        "status": "completed"})
    assert r.status_code == 302
    data = client.get("/api/dashboard?period=month").get_json()
    assert data["balance"] == "\u20b12,000.00" and data["income"] == "\u20b12,000.00"
    assert client.get("/dashboard").status_code == 200
    assert client.get("/transactions/").status_code == 200
    assert client.get("/budgets/").status_code == 200


def test_api_requires_login(client):
    assert client.get("/api/dashboard").status_code == 302


def test_edit_and_budget_pages_render_and_save(app, client):
    u = make_user()
    login(client)
    tx = add(u, "expense", "120", "Lunch", "Food and Drinks")
    r = client.get("/transactions/%d/edit" % tx.id)
    assert r.status_code == 200 and b"Lunch" in r.data
    r = client.post("/transactions/%d/edit" % tx.id, data={
        "description": "Lunch+", "amount": "150", "account_id": cash(u).id,
        "category_id": cat("Food and Drinks").id, "transaction_date": TODAY.isoformat(),
        "status": "completed"})
    assert r.status_code == 302
    assert Calc.available_balance(u.id) == Decimal("-150.00")
    assert client.get("/budgets/new").status_code == 200
    r = client.post("/budgets/new", data={
        "name": "Food", "budget_amount": "1500", "period_type": "monthly", "category_id": 0,
        "start_date": M_START.isoformat(), "end_date": TODAY.isoformat(), "warning_threshold": 75})
    assert r.status_code == 302
    b = Budget.query.first()
    assert client.get("/budgets/%d/edit" % b.id).status_code == 200
    assert b"150.00" in client.get("/budgets/").data


def test_pace_alert_projection(app):
    u = make_user()
    b = BudgetService.create(u, "Food", "1000", "monthly", date(2026, 10, 1), date(2026, 10, 31), 75)
    TS.create(u, "expense", "Groceries", "600", cash(u).id, None, date(2026, 10, 5))
    alerts = Calc.pace_alerts(Calc.statuses_for_user(u.id), today=date(2026, 10, 10))
    assert len(alerts) == 1 and "At this pace" in alerts[0] and "Food" in alerts[0]


def test_dashboard_page_shows_chart_and_alerts(app, client):
    u = make_user()
    login(client)
    add(u, "expense", "120", "Lunch", "Food and Drinks")
    html = client.get("/dashboard").data
    assert b"Spending by category" in html and b"Food and Drinks" in html
