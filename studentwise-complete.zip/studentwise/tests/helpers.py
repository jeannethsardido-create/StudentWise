from app.models import Account, Category
from app.services.auth_service import AuthService


def make_user(email="a@b.com", name="Ana"):
    return AuthService.register(name, email, "password123")


def cash(user):
    return Account.query.filter_by(user_id=user.id, account_name="Cash").first()


def cat(name, kind="expense"):
    return Category.query.filter_by(name=name, category_type=kind, user_id=None).first()


def login(client, email="a@b.com"):
    return client.post("/auth/login", data={"email": email, "password": "password123"})
