import io
from datetime import date
from decimal import Decimal
import pytest
from app.models import Bill, User, Transaction, SavingsGoal, ImportBatch
from app.services.bill_service import BillService, RecurringService, BillError, occurrences
from app.services.budget_service import BudgetCalculationService as Calc
from app.services.savings_service import SavingsService, SavingsError
from app.services.import_service import ImportService, ImportError_
from app.services.export_service import ExportService, safe_cell
from app.services.report_service import FinancialReportService as Rpt
from app.services.account_service import UserService, SettingsError
from app.services.transaction_service import TransactionService as TS
from tests.helpers import make_user, cash, cat, login

TODAY = date.today()


# ---------------- bills & recurring ----------------
def test_bill_is_not_spending_until_paid(app):
    u = make_user()
    b = BillService.create(u, "Rent", "500", TODAY, cat("Bills").id)
    assert Calc.available_balance(u.id) == Decimal("0.00")          # planned != spent
    BillService.mark_paid(u, b.id)
    assert Calc.available_balance(u.id) == Decimal("-500.00")
    with pytest.raises(BillError):
        BillService.mark_paid(u, b.id)                               # no double payment
    BillService.mark_unpaid(u, b.id)
    assert Calc.available_balance(u.id) == Decimal("0.00")
    assert Transaction.query.count() == 0


def test_moving_bill_date_creates_no_transaction(app):
    u = make_user()
    b = BillService.create(u, "Fee", "100", TODAY)
    BillService.update(u, b.id, "Fee", "100", date(2030, 1, 1))
    assert Transaction.query.count() == 0


def test_deleting_paid_expense_reopens_bill(app):
    u = make_user()
    b = BillService.create(u, "Fee", "100", TODAY)
    BillService.mark_paid(u, b.id)
    TS.delete(u, Bill.query.get(b.id).paid_transaction_id)
    assert Bill.query.get(b.id).status == "unpaid"


def test_occurrences_monthly_clamps_and_weekly():
    assert occurrences("monthly", date(2026, 1, 31), date(2026, 2, 1), date(2026, 3, 31)) == [date(2026, 2, 28), date(2026, 3, 31)]
    w = occurrences("weekly", date(2026, 10, 1), date(2026, 10, 10), date(2026, 10, 31))
    assert w == [date(2026, 10, 15), date(2026, 10, 22), date(2026, 10, 29)]


def test_recurring_generates_without_duplicates(app):
    u = make_user()
    RecurringService.create(u, "Internet", "999", "monthly", TODAY)
    n = Bill.query.filter_by(user_id=u.id).count()
    assert n >= 2
    assert RecurringService.generate_bills(u.id) == 0
    assert Bill.query.filter_by(user_id=u.id).count() == n


# ---------------- savings ----------------
def test_savings_progress_rules_and_balance_untouched(app):
    u = make_user()
    g = SavingsService.create(u, "Laptop", "1000", date(2030, 1, 1))
    SavingsService.add_entry(u, g.id, "contribution", "400")
    SavingsService.add_entry(u, g.id, "withdrawal", "100")
    p = SavingsService.progress(SavingsGoal.query.get(g.id))
    assert p["saved"] == Decimal("300.00") and p["remaining"] == Decimal("700.00") and p["per_week"] > 0
    with pytest.raises(SavingsError):
        SavingsService.add_entry(u, g.id, "withdrawal", "999")
    assert Calc.available_balance(u.id) == Decimal("0.00")            # reserved, not spent or earned
    SavingsService.add_entry(u, g.id, "contribution", "700")
    assert SavingsGoal.query.get(g.id).status == "completed"


# ---------------- import ----------------
CSV = ("date,description,amount,type,reference\n"
       "2026-10-01,Allowance,2000,income,R1\n"
       "2026-10-02,Fare,-24,,R2\n"
       "2026-10-02,Fare,-24,,R2\n"
       "bad-date,Oops,-5,,R3\n")


def test_import_preview_confirm_and_reimport(app):
    u = make_user()
    b = ImportService.start_preview(u, cash(u).id, "s.csv", CSV.encode())
    _, rows, counts = ImportService.preview(u, b.id)
    assert counts == {"ok": 2, "duplicate": 1, "error": 1}
    assert Transaction.query.count() == 0                              # preview saves nothing
    ImportService.confirm(u, b.id)
    assert Transaction.query.count() == 2
    assert Calc.available_balance(u.id) == Decimal("1976.00")
    assert Transaction.query.filter_by(external_transaction_id="ref:R1").first().source == "csv_import"
    b2 = ImportService.start_preview(u, cash(u).id, "s.csv", CSV.encode())
    assert ImportService.preview(u, b2.id)[2]["ok"] == 0               # re-import = all duplicates


def test_import_rejects_bad_files(app):
    u = make_user()
    with pytest.raises(ImportError_):
        ImportService.start_preview(u, cash(u).id, "x.csv", b"foo,bar\n1,2\n")
    with pytest.raises(ImportError_):
        ImportService.start_preview(u, cash(u).id, "x.csv", b"\xff\xfe\x00bad")
    assert ImportBatch.query.count() == 0


def test_import_batch_isolated_between_users(app):
    a, b = make_user("a@b.com"), make_user("b@b.com", "Ben")
    batch = ImportService.start_preview(a, cash(a).id, "s.csv", CSV.encode())
    with pytest.raises(LookupError):
        ImportService.preview(b, batch.id)
    with pytest.raises(ImportError_):
        ImportService.start_preview(b, cash(a).id, "s.csv", CSV.encode())


# ---------------- export / reports ----------------
def test_csv_export_blocks_formula_injection_and_other_users(app):
    a, b = make_user("a@b.com"), make_user("b@b.com", "Ben")
    TS.create(a, "expense", "=HYPERLINK(\"x\")", "10", cash(a).id, None, TODAY)
    TS.create(b, "expense", "Bens secret", "10", cash(b).id, None, TODAY)
    out = ExportService.transactions_csv(a.id)
    assert "'=HYPERLINK" in out and "Bens secret" not in out
    assert safe_cell("@x") == "'@x" and safe_cell("hello") == "hello"


def test_monthly_history_totals(app):
    u = make_user()
    TS.create(u, "income", "Allowance", "2000", cash(u).id, None, TODAY)
    TS.create(u, "expense", "Food", "500", cash(u).id, cat("Food and Drinks").id, TODAY)
    last = Rpt.monthly_history(u.id, 3)[-1]
    assert last["income"] == Decimal("2000.00") and last["net"] == Decimal("1500.00")
    assert last["savings_rate"] == Decimal("75.0") and last["top_category"] == "Food and Drinks"


# ---------------- settings ----------------
def test_change_password_and_delete_account_removes_everything(app):
    u = make_user()
    with pytest.raises(SettingsError):
        UserService.change_password(u, "wrong", "newpassword1")
    UserService.change_password(u, "password123", "newpassword1")
    assert u.check_password("newpassword1")
    BillService.create(u, "Fee", "10", TODAY)
    SavingsService.create(u, "G", "100")
    ImportService.start_preview(u, cash(u).id, "s.csv", CSV.encode())
    with pytest.raises(SettingsError):
        UserService.delete_user(u, "bad")
    UserService.delete_user(u, "newpassword1")
    assert User.query.count() == 0 and Bill.query.count() == 0 and ImportBatch.query.count() == 0


# ---------------- routes / isolation ----------------
PAGES = ["/dashboard", "/bills/", "/bills/new", "/recurring/", "/recurring/new", "/savings/", "/savings/new",
         "/reports/", "/reports/history", "/import/", "/settings/", "/transactions/", "/budgets/"]


def test_all_pages_render(app, client):
    make_user()
    login(client)
    for url in PAGES:
        assert client.get(url).status_code == 200, url
    assert client.get("/import/sample.csv").status_code == 200
    assert client.get("/settings/backup.json").status_code == 200
    assert client.get("/reports/export.csv").mimetype == "text/csv"


def test_pages_require_login(client):
    for url in PAGES:
        assert client.get(url).status_code == 302, url


def test_other_users_cannot_touch_bills_or_goals(app, client):
    a, b = make_user("a@b.com"), make_user("b@b.com", "Ben")
    bill = BillService.create(a, "Rent", "100", TODAY)
    goal = SavingsService.create(a, "Laptop", "500")
    login(client, "b@b.com")
    assert client.post("/bills/%d/pay" % bill.id).status_code == 404
    assert client.get("/bills/%d/edit" % bill.id).status_code == 404
    assert client.get("/savings/%d" % goal.id).status_code == 404
    assert client.post("/savings/%d/delete" % goal.id).status_code == 404


def test_full_flow_through_routes(app, client):
    u = make_user()
    login(client)
    r = client.post("/bills/new", data={"name": "Tuition", "amount": "1500", "due_date": TODAY.isoformat(),
                                        "category_id": 0, "account_id": 0})
    assert r.status_code == 302
    bill = Bill.query.first()
    assert client.post("/bills/%d/pay" % bill.id).status_code == 302
    assert Calc.available_balance(u.id) == Decimal("-1500.00")
    r = client.post("/import/", data={"account_id": cash(u).id, "file": (io.BytesIO(CSV.encode()), "s.csv")},
                    content_type="multipart/form-data")
    assert r.status_code == 302
    batch = ImportBatch.query.first()
    assert b"Duplicate" in client.get("/import/%d/preview" % batch.id).data
    client.post("/import/%d/confirm" % batch.id)
    assert Transaction.query.filter_by(source="csv_import").count() == 2
