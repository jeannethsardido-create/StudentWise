from datetime import date, timedelta
from decimal import Decimal
import pytest
from app.extensions import db
from app.models import Notification, User
from app.services.bill_service import BillService
from app.services.budget_service import BudgetService
from app.services.notification_service import (NotificationService as NS, normalize_phone, EmailProvider,
                                               SemaphoreSMSProvider)
from app.services.account_service import UserService
from app.services.transaction_service import TransactionService as TS
from tests.helpers import make_user, cash, cat, login

TODAY = date.today()


@pytest.fixture
def fake_channels(monkeypatch):
    """Pretend email/SMS are configured and record what would be sent (nothing leaves the test)."""
    sent = []
    monkeypatch.setattr(EmailProvider, "is_configured", lambda self: True)
    monkeypatch.setattr(SemaphoreSMSProvider, "is_configured", lambda self: True)
    monkeypatch.setattr(EmailProvider, "send", lambda self, u, t, m: sent.append(("email", u.email, t)) or "sent")
    monkeypatch.setattr(SemaphoreSMSProvider, "send", lambda self, u, t, m: sent.append(("sms", u.phone, t)) or "sent")
    return sent


def test_phone_normalization():
    assert normalize_phone("0917 123 4567") == "09171234567"
    assert normalize_phone("+639171234567") == "09171234567"
    assert normalize_phone("639171234567") == "09171234567"
    assert normalize_phone("12345") is None and normalize_phone("") is None


def test_bill_due_soon_alert_sent_once_to_email_and_sms(app, fake_channels):
    u = make_user()
    u.phone, u.notify_sms = "09171234567", True
    db.session.commit()
    BillService.create(u, "Internet", "999", TODAY + timedelta(days=2))
    assert NS.generate_for_user(u) == 1
    assert NS.generate_for_user(u) == 0                     # refreshing never duplicates
    assert [c[0] for c in fake_channels] == ["email", "sms"]
    assert fake_channels[0][1] == "a@b.com" and fake_channels[1][1] == "09171234567"
    n = Notification.query.one()
    assert n.email_status == "sent" and n.sms_status == "sent" and "Internet" in n.title


def test_far_future_and_paid_bills_do_not_alert(app, fake_channels):
    u = make_user()
    BillService.create(u, "Later", "10", TODAY + timedelta(days=30))
    b = BillService.create(u, "Paid", "10", TODAY)
    BillService.mark_paid(u, b.id)
    assert NS.generate_for_user(u) == 0 and fake_channels == []


def test_overdue_and_budget_alerts(app, fake_channels):
    u = make_user()
    BillService.create(u, "Rent", "500", TODAY - timedelta(days=2))
    BudgetService.create(u, "Food", "100", "monthly", TODAY - timedelta(days=1), TODAY + timedelta(days=5), 50,
                         cat("Food and Drinks").id)
    TS.create(u, "expense", "Feast", "60", cash(u).id, cat("Food and Drinks").id, TODAY)
    assert NS.generate_for_user(u) == 2
    types = {n.notification_type for n in Notification.query.all()}
    assert types == {"bill_overdue", "budget_warning"}
    TS.create(u, "expense", "More", "60", cash(u).id, cat("Food and Drinks").id, TODAY)
    assert NS.generate_for_user(u) == 1                     # now "exceeded", a new event
    assert Notification.query.filter_by(notification_type="budget_exceeded").count() == 1


def test_unconfigured_channels_still_create_in_app_alert(app):
    u = make_user()
    BillService.create(u, "Fee", "10", TODAY)
    NS.generate_for_user(u)
    n = Notification.query.one()
    assert n.email_status == "not_configured" and n.sms_status == "off"   # never claims "sent"


def test_provider_failure_is_recorded_not_raised(app, monkeypatch):
    monkeypatch.setattr(EmailProvider, "is_configured", lambda self: True)

    def boom(self, u, t, m):
        raise ConnectionError("smtp down password=secret")
    monkeypatch.setattr(EmailProvider, "send", boom)
    u = make_user()
    BillService.create(u, "Fee", "10", TODAY)
    NS.generate_for_user(u)
    n = Notification.query.one()
    assert n.email_status == "failed" and "secret" not in (n.message + n.title)


def test_email_off_means_no_email(app, fake_channels):
    u = make_user()
    u.notify_email = False
    db.session.commit()
    BillService.create(u, "Fee", "10", TODAY)
    NS.generate_for_user(u)
    assert fake_channels == [] and Notification.query.one().email_status == "off"


def test_center_read_dismiss_and_isolation(app, client, fake_channels):
    a, b = make_user("a@b.com"), make_user("b@b.com", "Ben")
    BillService.create(a, "Fee", "10", TODAY)
    NS.generate_for_user(a)
    nid = Notification.query.one().id
    assert NS.unread_count(a.id) == 1 and NS.unread_count(b.id) == 0
    login(client, "b@b.com")
    assert client.post("/notifications/%d/read" % nid).status_code == 404
    assert client.post("/notifications/%d/delete" % nid).status_code == 404
    client.get("/auth/logout")
    client2 = app.test_client()
    login(client2, "a@b.com")
    assert b"Fee" in client2.get("/notifications/").data
    client2.post("/notifications/%d/read" % nid)
    assert NS.unread_count(a.id) == 0
    client2.post("/notifications/%d/delete" % nid)
    assert Notification.query.count() == 0


def test_settings_phone_validation_and_test_alert(app, client, fake_channels):
    u = make_user()
    login(client)
    client.post("/settings/notifications", data={"n-phone": "123", "n-notify_email": "y"})
    assert User.query.first().phone is None
    client.post("/settings/notifications", data={"n-phone": "", "n-notify_sms": "y"})
    assert User.query.first().notify_sms is False           # can't enable SMS without a number
    client.post("/settings/notifications", data={"n-phone": "+63 917 123 4567", "n-notify_email": "y", "n-notify_sms": "y"})
    u = User.query.first()
    assert u.phone == "09171234567" and u.notify_sms and u.notify_email
    client.post("/settings/notifications/test")
    assert ("sms", "09171234567", "Test notification") in fake_channels
    assert client.get("/settings/").status_code == 200 and client.get("/dashboard").status_code == 200


def test_cli_send_reminders_and_account_deletion(app, fake_channels):
    u = make_user()
    BillService.create(u, "Fee", "10", TODAY)
    assert NS.send_reminders_for_all() == 1
    r = app.test_cli_runner().invoke(args=["send-reminders"])
    assert "New alerts created: 0" in r.output
    UserService.delete_user(u, "password123")
    assert Notification.query.count() == 0 and User.query.count() == 0


def test_email_provider_smtp_sequence(app, monkeypatch):
    calls = []

    class FakeSMTP:
        def __init__(self, host, port, timeout=None):
            calls.append(("connect", host, port, timeout))
        def starttls(self, context=None): calls.append(("starttls",))
        def login(self, user, pw): calls.append(("login", user))
        def send_message(self, msg): calls.append(("send", msg["To"], msg["Subject"]))
        def quit(self): calls.append(("quit",))

    monkeypatch.setattr("app.services.notification_service.smtplib.SMTP", FakeSMTP)
    app.config.update(MAIL_SERVER="smtp.example.com", MAIL_PORT=587, MAIL_USERNAME="me@example.com", MAIL_PASSWORD="app-pass")
    u = make_user()
    assert EmailProvider().send(u, "Bill due", "Internet is due today.") == "sent"
    assert [c[0] for c in calls] == ["connect", "starttls", "login", "send", "quit"]
    assert calls[0][3] == 8 and calls[3][1] == "a@b.com" and calls[3][2] == "StudentWise: Bill due"
